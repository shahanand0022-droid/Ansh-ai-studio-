import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as StudioShell } from "./studio-shell-DNU2F18M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DH0V9A0V.js
var import_jsx_runtime = require_jsx_runtime();
var DESK = [
	{
		title: "Conversation",
		copy: "Open the microphone for a live voice line, or record a single turn. Speech becomes text, then a spoken reply."
	},
	{
		title: "Generator",
		copy: "Turn a script into narration in English, Hindi, or Nepali, with female, male, and neutral voices."
	},
	{
		title: "Documentary",
		copy: "Split a script into scenes, render each one, then lay a music bed beside the voice and download both."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, {
		active: "studio",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-end gap-10 lg:grid-cols-[minmax(0,1.4fr)_minmax(16rem,0.8fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-muted",
					children: "VOICE DESK"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-3 max-w-xl text-5xl leading-[1.02] sm:text-6xl",
					children: "NOVA AI STUDIO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg text-muted",
					children: "A quiet room for spoken work. Voice Studio handles live conversation, narration, and documentary scenes without sending the API key to the browser."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/voice",
					className: "btn btn-primary mt-6",
					children: "Open Voice Studio"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "panel divide-y divide-line p-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Languages"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "English, Hindi, Nepali" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Voices"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Female, male, neutral" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Output"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "MP3, WAV mix" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "Live line"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Realtime where open" })]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-10 divide-y divide-line border-y border-line",
			children: DESK.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-2 py-5 sm:grid-cols-[8rem_minmax(0,1fr)] sm:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-faint",
					children: ["0", index + 1]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl leading-none",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: item.copy
				})] })]
			}, item.title))
		})]
	});
}
//#endregion
export { Home as component };
