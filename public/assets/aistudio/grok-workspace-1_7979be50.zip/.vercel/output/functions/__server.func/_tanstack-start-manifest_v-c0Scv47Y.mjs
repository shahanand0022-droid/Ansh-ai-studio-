//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-c0Scv47Y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/voice"],
		preloads: ["/assets/index-CcG_WUrs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CcG_WUrs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BcQrI-kf.js", "/assets/studio-shell-BvrOcW_c.js"]
	},
	"/voice": {
		filePath: "/workspace/src/routes/voice.tsx",
		children: void 0,
		preloads: ["/assets/voice-CfQimDNN.js", "/assets/studio-shell-BvrOcW_c.js"]
	}
} });
//#endregion
export { tsrStartManifest };
