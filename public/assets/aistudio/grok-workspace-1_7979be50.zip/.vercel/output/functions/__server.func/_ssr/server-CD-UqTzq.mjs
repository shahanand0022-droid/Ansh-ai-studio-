import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as VOICES } from "./catalog-CAwxWQ1N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-CD-UqTzq.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var TTS_URL = "https://api.x.ai/v1/tts";
var STT_URL = "https://api.x.ai/v1/stt";
var CHAT_URL = "https://api.x.ai/v1/chat/completions";
var SECRET_URL = "https://api.x.ai/v1/realtime/client_secrets";
var LANGUAGES = /* @__PURE__ */ new Set([
	"en",
	"hi",
	"ne"
]);
var STYLES = /* @__PURE__ */ new Set([
	"documentary",
	"storytelling",
	"educational",
	"conversational"
]);
var VOICE_IDS = new Set(VOICES.map((voice) => voice.id));
var AUDIO_MIMES = /* @__PURE__ */ new Set([
	"audio/webm",
	"audio/ogg",
	"audio/mpeg",
	"audio/mp3",
	"audio/mp4",
	"audio/wav",
	"audio/x-wav",
	"audio/wave",
	"video/webm"
]);
var STYLE_NOTE = {
	documentary: "Speak like a cinematic documentary narrator: measured, vivid, and calm.",
	storytelling: "Speak like a storyteller sitting close to the listener.",
	educational: "Speak like a clear teacher. Explain without rushing.",
	conversational: "Speak like a natural conversation partner. Keep it warm and brief."
};
var LANG_NAME = {
	en: "English",
	hi: "Hindi",
	ne: "Nepali"
};
function apiKey() {
	const key = process.env.XAI_API_KEY;
	return key && key.trim() ? key : null;
}
function missingKey() {
	return "Voice is unavailable because the server has no XAI_API_KEY. The key must stay on the server. It is never entered in the browser.";
}
function readError(status, raw) {
	let msg = raw.slice(0, 400);
	try {
		const parsed = JSON.parse(raw);
		if (typeof parsed.error === "string") msg = parsed.error;
		else if (parsed.error && typeof parsed.error === "object" && "message" in parsed.error) {
			const inner = parsed.error.message;
			if (typeof inner === "string") msg = inner;
		} else if (typeof parsed.message === "string") msg = parsed.message;
	} catch {}
	if (/spending-limit|run out of credits|need a grok subscription/i.test(msg)) return "xAI voice credits are blocked for this studio key (spending limit or no credits). Add API credits, then generate again. The key stays on the server.";
	if (status === 401) return "The voice service rejected the server key.";
	if (status === 404) return "That voice is not available. Choose another voice.";
	return msg || `Voice service error (${status}).`;
}
async function xaiFetch(url, init) {
	const first = await fetch(url, init);
	if (first.status !== 429 && first.status !== 503) return first;
	await new Promise((resolve) => setTimeout(resolve, 500));
	return fetch(url, init);
}
function clampSpeed(value) {
	if (!Number.isFinite(value)) return 1;
	return Math.min(1.5, Math.max(.7, Math.round(value * 100) / 100));
}
function styleText(text, style) {
	const clean = text.replace(/\s+\n/g, "\n").trim();
	if (style === "documentary" || style === "storytelling") return clean.replace(/([.!?।])\s+/g, "$1 [pause] ");
	return clean;
}
function assertSpeech(input) {
	if (!input || typeof input !== "object") throw new Error("Missing voice request.");
	const data = input;
	const text = typeof data.text === "string" ? data.text.trim() : "";
	if (!text) throw new Error("Enter text to speak.");
	if (text.length > 4e3) throw new Error("Keep a generation under 4,000 characters.");
	const voiceId = typeof data.voiceId === "string" ? data.voiceId : "";
	if (!VOICE_IDS.has(voiceId)) throw new Error("Choose a supported voice.");
	const language = data.language;
	if (language !== "en" && language !== "hi" && language !== "ne") throw new Error("Choose English, Hindi, or Nepali.");
	const style = data.style;
	if (typeof style !== "string" || !STYLES.has(style)) throw new Error("Choose a narration style.");
	return {
		text,
		voiceId,
		language,
		speed: clampSpeed(typeof data.speed === "number" ? data.speed : Number(data.speed)),
		style
	};
}
async function synthesize(input, key) {
	const spoken = styleText(input.text, input.style);
	const languages = input.language === "ne" ? ["ne", "auto"] : [input.language];
	let last = "Voice synthesis failed.";
	for (const language of languages) {
		const res = await xaiFetch(TTS_URL, {
			method: "POST",
			headers: {
				Authorization: `Bearer ${key}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				text: spoken,
				voice_id: input.voiceId,
				language,
				speed: input.speed,
				text_normalization: true,
				output_format: {
					codec: "mp3",
					sample_rate: 24e3,
					bit_rate: 128e3
				}
			})
		});
		if (res.ok) {
			const bytes = new Uint8Array(await res.arrayBuffer());
			if (bytes.byteLength < 32) return {
				ok: false,
				error: "The voice service returned empty audio."
			};
			return {
				ok: true,
				audioBase64: Buffer.from(bytes).toString("base64"),
				mime: "audio/mpeg",
				languageUsed: language
			};
		}
		last = readError(res.status, await res.text());
		if (res.status !== 400 || language === languages[languages.length - 1]) break;
	}
	return {
		ok: false,
		error: last
	};
}
function extFor(mime) {
	if (mime.includes("webm")) return "webm";
	if (mime.includes("ogg")) return "ogg";
	if (mime.includes("mp4")) return "mp4";
	if (mime.includes("wav")) return "wav";
	return "mp3";
}
async function transcribe(audioBase64, mime, language, key) {
	if (audioBase64.length > 45e5) return {
		ok: false,
		error: "That recording is too long. Keep a turn under about 45 seconds."
	};
	const bytes = Buffer.from(audioBase64, "base64");
	const form = new FormData();
	form.append("model", "grok-voice-transcribe-2.0");
	if (language !== "ne") form.append("language", language);
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	form.append("file", new Blob([copy]), `turn.${extFor(mime)}`);
	const res = await xaiFetch(STT_URL, {
		method: "POST",
		headers: { Authorization: `Bearer ${key}` },
		body: form
	});
	if (!res.ok) return {
		ok: false,
		error: readError(res.status, await res.text())
	};
	const body = await res.json();
	const text = (body.text || body.transcript || "").trim();
	if (!text) return {
		ok: false,
		error: "No speech was detected. Try again a little closer to the microphone."
	};
	return {
		ok: true,
		text
	};
}
function cleanHistory(value) {
	if (!Array.isArray(value)) return [];
	const turns = [];
	for (const item of value.slice(-8)) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		if (row.role !== "user" && row.role !== "assistant") continue;
		if (typeof row.content !== "string") continue;
		const content = row.content.trim().slice(0, 2e3);
		if (!content) continue;
		turns.push({
			role: row.role,
			content
		});
	}
	return turns;
}
async function complete(userText, history, language, style, key) {
	const res = await xaiFetch(CHAT_URL, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${key}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 220,
			messages: [
				{
					role: "system",
					content: `You are NOVA, the voice of NOVA AI Studio. Reply only in ${LANG_NAME[language]}. ${STYLE_NOTE[style]} Two to four spoken sentences. No markdown, no lists, no stage directions.`
				},
				...history,
				{
					role: "user",
					content: userText
				}
			]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: readError(res.status, await res.text())
	};
	const reply = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!reply) return {
		ok: false,
		error: "The assistant returned an empty reply."
	};
	return {
		ok: true,
		text: reply.slice(0, 1500)
	};
}
var synthesizeSpeech_createServerFn_handler = createServerRpc({
	id: "9811a5c2d3cb151df62f5f712f7f9948149a06c5aebfd46fbe07648a8926a9d1",
	name: "synthesizeSpeech",
	filename: "src/lib/voice/server.ts"
}, (opts) => synthesizeSpeech.__executeServer(opts));
var synthesizeSpeech = createServerFn({ method: "POST" }).validator((input) => assertSpeech(input)).handler(synthesizeSpeech_createServerFn_handler, async ({ data }) => {
	const key = apiKey();
	if (!key) return {
		ok: false,
		error: missingKey()
	};
	return synthesize(data, key);
});
var createVoiceSession_createServerFn_handler = createServerRpc({
	id: "ba9a85fe51c5474412ce86cb991ef1389dfaa169108a59be7aa48c911a535f3a",
	name: "createVoiceSession",
	filename: "src/lib/voice/server.ts"
}, (opts) => createVoiceSession.__executeServer(opts));
var createVoiceSession = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") return {};
	return input;
}).handler(createVoiceSession_createServerFn_handler, async () => {
	const key = apiKey();
	if (!key) return {
		ok: false,
		error: missingKey()
	};
	const res = await xaiFetch(SECRET_URL, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${key}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({ expires_after: { seconds: 300 } })
	});
	if (!res.ok) return {
		ok: false,
		error: readError(res.status, await res.text())
	};
	const body = await res.json();
	const token = body.value || body.client_secret?.value;
	if (!token) return {
		ok: false,
		error: "The voice service did not return a live session token."
	};
	return {
		ok: true,
		token,
		expiresAt: body.expires_at ?? 0
	};
});
var speakTurn_createServerFn_handler = createServerRpc({
	id: "830a0416334c9ea69a182408dc9ec5621dce7f3a63aa26f04f090fc3b0f80391",
	name: "speakTurn",
	filename: "src/lib/voice/server.ts"
}, (opts) => speakTurn.__executeServer(opts));
var speakTurn = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing conversation turn.");
	const data = input;
	const speech = assertSpeech({
		text: typeof data.text === "string" && data.text.trim() ? data.text : "turn",
		voiceId: data.voiceId,
		language: data.language,
		speed: data.speed,
		style: data.style
	});
	const text = typeof data.text === "string" ? data.text.trim() : "";
	const audioBase64 = typeof data.audioBase64 === "string" ? data.audioBase64 : "";
	const mime = typeof data.mime === "string" ? data.mime.split(";")[0].trim().toLowerCase() : "";
	if (!text && !audioBase64) throw new Error("Record or type something first.");
	if (audioBase64 && !AUDIO_MIMES.has(mime)) throw new Error("That recording format is not supported.");
	if (!LANGUAGES.has(speech.language)) throw new Error("Choose English, Hindi, or Nepali.");
	return {
		speech,
		text,
		audioBase64,
		mime,
		history: cleanHistory(data.history)
	};
}).handler(speakTurn_createServerFn_handler, async ({ data }) => {
	const key = apiKey();
	if (!key) return {
		ok: false,
		error: missingKey()
	};
	let userText = data.text;
	if (data.audioBase64) {
		const heard = await transcribe(data.audioBase64, data.mime, data.speech.language, key);
		if (!heard.ok) return {
			ok: false,
			error: heard.error
		};
		userText = heard.text;
	}
	const reply = await complete(userText, data.history, data.speech.language, data.speech.style, key);
	if (!reply.ok) return {
		ok: false,
		error: reply.error,
		userText
	};
	const spoken = await synthesize({
		...data.speech,
		text: reply.text,
		style: "conversational"
	}, key);
	if (!spoken.ok) return {
		ok: false,
		error: spoken.error,
		userText,
		replyText: reply.text
	};
	return {
		ok: true,
		userText,
		replyText: reply.text,
		audioBase64: spoken.audioBase64,
		mime: "audio/mpeg",
		languageUsed: spoken.languageUsed
	};
});
//#endregion
export { createVoiceSession_createServerFn_handler, speakTurn_createServerFn_handler, synthesizeSpeech_createServerFn_handler };
