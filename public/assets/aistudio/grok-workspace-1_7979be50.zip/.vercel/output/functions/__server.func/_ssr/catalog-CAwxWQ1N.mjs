//#region node_modules/.nitro/vite/services/ssr/assets/catalog-CAwxWQ1N.js
/** Built-in xAI voice ids. Gender follows the published roster; Sal is the documented neutral voice. */
var VOICES = [
	{
		id: "eve",
		name: "Eve",
		gender: "female",
		tone: "Energetic, upbeat"
	},
	{
		id: "ara",
		name: "Ara",
		gender: "female",
		tone: "Warm, conversational"
	},
	{
		id: "luna",
		name: "Luna",
		gender: "female",
		tone: "Soft, clear"
	},
	{
		id: "celeste",
		name: "Celeste",
		gender: "female",
		tone: "Bright, precise"
	},
	{
		id: "iris",
		name: "Iris",
		gender: "female",
		tone: "Calm, measured"
	},
	{
		id: "ursa",
		name: "Ursa",
		gender: "female",
		tone: "Low, grounded"
	},
	{
		id: "carina",
		name: "Carina",
		gender: "female",
		tone: "Light, articulate"
	},
	{
		id: "aurora",
		name: "Aurora",
		gender: "female",
		tone: "Open, cinematic"
	},
	{
		id: "liora",
		name: "Liora",
		gender: "female",
		tone: "Gentle, narrative"
	},
	{
		id: "rex",
		name: "Rex",
		gender: "male",
		tone: "Confident, clear"
	},
	{
		id: "leo",
		name: "Leo",
		gender: "male",
		tone: "Authoritative, cinematic"
	},
	{
		id: "orion",
		name: "Orion",
		gender: "male",
		tone: "Deep, documentary"
	},
	{
		id: "atlas",
		name: "Atlas",
		gender: "male",
		tone: "Steady, instructional"
	},
	{
		id: "castor",
		name: "Castor",
		gender: "male",
		tone: "Warm, storytelling"
	},
	{
		id: "sirius",
		name: "Sirius",
		gender: "male",
		tone: "Bright, direct"
	},
	{
		id: "helios",
		name: "Helios",
		gender: "male",
		tone: "Open, presentational"
	},
	{
		id: "kepler",
		name: "Kepler",
		gender: "male",
		tone: "Thoughtful, educational"
	},
	{
		id: "zenith",
		name: "Zenith",
		gender: "male",
		tone: "Crisp, modern"
	},
	{
		id: "sal",
		name: "Sal",
		gender: "neutral",
		tone: "Smooth, balanced"
	}
];
//#endregion
export { VOICES as t };
