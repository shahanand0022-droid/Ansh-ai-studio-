import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-shell-DNU2F18M.js
var import_jsx_runtime = require_jsx_runtime();
function StudioShell({ active, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 place-items-center rounded-lg border border-line bg-subtle",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-4 w-3 border-l-2 border-r-2 border-accent" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs font-medium tracking-[0.16em] text-muted",
						children: "NOVA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium leading-none",
						children: "AI STUDIO"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex items-center gap-1",
					"aria-label": "Studio",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-current": active === "studio" ? "page" : void 0,
						className: `inline-flex h-11 items-center rounded-full px-4 text-sm font-medium ${active === "studio" ? "bg-accent text-accent-fg" : "text-muted"}`,
						children: "Studio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/voice",
						"aria-current": active === "voice" ? "page" : void 0,
						className: `inline-flex h-11 items-center rounded-full px-4 text-sm font-medium ${active === "voice" ? "bg-accent text-accent-fg" : "text-muted"}`,
						children: "Voice Studio"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-6xl px-4 py-8 sm:py-10",
			children
		})]
	});
}
//#endregion
export { StudioShell as t };
