import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LoaderCircle, i as Mic, o as Download, r as Square, t as Upload } from "../_libs/lucide-react.mjs";
import { t as StudioShell } from "./studio-shell-DNU2F18M.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as VOICES } from "./catalog-CAwxWQ1N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/voice-YLRwErMF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function base64ToBytes(b64) {
	const bin = atob(b64);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
function bytesToBase64(bytes) {
	let binary = "";
	const step = 32768;
	for (let i = 0; i < bytes.length; i += step) binary += String.fromCharCode(...bytes.subarray(i, i + step));
	return btoa(binary);
}
function audioUrlFromBase64(b64, mime) {
	const bytes = base64ToBytes(b64);
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	return URL.createObjectURL(new Blob([copy], { type: mime }));
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function downloadBase64(b64, filename, mime) {
	const bytes = base64ToBytes(b64);
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	downloadBlob(new Blob([copy], { type: mime }), filename);
}
function blobToBase64(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const value = String(reader.result ?? "");
			const comma = value.indexOf(",");
			resolve(comma >= 0 ? value.slice(comma + 1) : value);
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read the recording."));
		reader.readAsDataURL(blob);
	});
}
function crc32(data) {
	let crc = -1;
	for (let i = 0; i < data.length; i++) {
		crc ^= data[i];
		for (let bit = 0; bit < 8; bit++) crc = crc >>> 1 ^ 3988292384 & -(crc & 1);
	}
	return ~crc >>> 0;
}
function zipStore(files) {
	const chunks = [];
	const central = [];
	let offset = 0;
	const encoder = new TextEncoder();
	for (const file of files) {
		const nameBytes = encoder.encode(file.name);
		const name = nameBytes.buffer.slice(nameBytes.byteOffset, nameBytes.byteOffset + nameBytes.byteLength);
		const data = file.data.buffer.slice(file.data.byteOffset, file.data.byteOffset + file.data.byteLength);
		const crc = crc32(file.data);
		const local = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(30));
		local.setUint32(0, 67324752, true);
		local.setUint16(4, 20, true);
		local.setUint32(14, crc, true);
		local.setUint32(18, data.byteLength, true);
		local.setUint32(22, data.byteLength, true);
		local.setUint16(26, name.byteLength, true);
		const cen = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(46));
		cen.setUint32(0, 33639248, true);
		cen.setUint16(4, 20, true);
		cen.setUint16(6, 20, true);
		cen.setUint32(16, crc, true);
		cen.setUint32(20, data.byteLength, true);
		cen.setUint32(24, data.byteLength, true);
		cen.setUint16(28, name.byteLength, true);
		cen.setUint32(42, offset, true);
		chunks.push(local.buffer, name, data);
		central.push(cen.buffer, name);
		offset += local.byteLength + name.byteLength + data.byteLength;
	}
	const centralSize = central.reduce((sum, part) => sum + part.byteLength, 0);
	const end = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(22));
	end.setUint32(0, 101010256, true);
	end.setUint16(8, files.length, true);
	end.setUint16(10, files.length, true);
	end.setUint32(12, centralSize, true);
	end.setUint32(16, offset, true);
	return new Blob([
		...chunks,
		...central,
		end.buffer
	], { type: "application/zip" });
}
function encodeWav(buffer) {
	const channels = Math.min(2, buffer.numberOfChannels);
	const rate = buffer.sampleRate;
	const frames = buffer.length;
	const block = channels * 2;
	const dataSize = frames * block;
	const out = new ArrayBuffer(44 + dataSize);
	const view = new DataView(out);
	const write = (offset, text) => {
		for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
	};
	write(0, "RIFF");
	view.setUint32(4, 36 + dataSize, true);
	write(8, "WAVE");
	write(12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, channels, true);
	view.setUint32(24, rate, true);
	view.setUint32(28, rate * block, true);
	view.setUint16(32, block, true);
	view.setUint16(34, 16, true);
	write(36, "data");
	view.setUint32(40, dataSize, true);
	const chans = [];
	for (let c = 0; c < channels; c++) chans.push(buffer.getChannelData(c));
	let offset = 44;
	for (let i = 0; i < frames; i++) for (let c = 0; c < channels; c++) {
		const sample = Math.max(-1, Math.min(1, chans[c][i] ?? 0));
		view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
		offset += 2;
	}
	return new Blob([out], { type: "audio/wav" });
}
async function mixNarration(voiceUrls, music, voiceGain, musicGain) {
	const ctx = new AudioContext();
	try {
		const voices = [];
		for (const url of voiceUrls) {
			const raw = await fetch(url).then((res) => res.arrayBuffer());
			voices.push(await ctx.decodeAudioData(raw.slice(0)));
		}
		const musicBuffer = music ? await ctx.decodeAudioData((await music.arrayBuffer()).slice(0)) : null;
		const rate = ctx.sampleRate;
		const gap = Math.floor(rate * .35);
		const voiceFrames = voices.reduce((sum, item) => sum + item.length, 0) + gap * Math.max(0, voices.length - 1);
		const offline = new OfflineAudioContext(2, Math.max(voiceFrames, rate), rate);
		let cursor = 0;
		for (const item of voices) {
			const src = offline.createBufferSource();
			src.buffer = item;
			const gain = offline.createGain();
			gain.gain.value = voiceGain;
			src.connect(gain).connect(offline.destination);
			src.start(cursor / rate);
			cursor += item.length + gap;
		}
		if (musicBuffer && musicGain > 0) {
			let at = 0;
			const end = voiceFrames / rate;
			while (at < end) {
				const src = offline.createBufferSource();
				src.buffer = musicBuffer;
				const gain = offline.createGain();
				gain.gain.value = musicGain;
				src.connect(gain).connect(offline.destination);
				src.start(at);
				at += musicBuffer.duration;
			}
		}
		return encodeWav(await offline.startRendering());
	} finally {
		await ctx.close();
	}
}
function downsample(input, inRate, outRate) {
	if (inRate === outRate) return input;
	const ratio = inRate / outRate;
	const length = Math.round(input.length / ratio);
	const out = new Float32Array(length);
	for (let i = 0; i < length; i++) {
		const pos = i * ratio;
		const i0 = Math.floor(pos);
		const i1 = Math.min(i0 + 1, input.length - 1);
		const t = pos - i0;
		out[i] = input[i0] * (1 - t) + input[i1] * t;
	}
	return out;
}
function floatToPcm16(input) {
	const out = new Int16Array(input.length);
	for (let i = 0; i < input.length; i++) {
		const sample = Math.max(-1, Math.min(1, input[i]));
		out[i] = sample < 0 ? sample * 32768 : sample * 32767;
	}
	return out;
}
var LANG_NAME = {
	en: "English",
	hi: "Hindi",
	ne: "Nepali"
};
var STYLE_NOTE = {
	documentary: "You narrate like a cinematic documentary.",
	storytelling: "You tell stories with a close, human pace.",
	educational: "You explain clearly, like a good teacher.",
	conversational: "You talk like a natural conversation partner."
};
var LiveVoiceSession = class {
	handlers;
	ws = null;
	ctx = null;
	stream = null;
	processor = null;
	micAnalyser = null;
	outAnalyser = null;
	gain = null;
	nextTime = 0;
	playbackUntil = 0;
	sources = [];
	pcmCarry = /* @__PURE__ */ new Int16Array(0);
	ready = false;
	closed = false;
	assistantId = "";
	assistantText = "";
	constructor(handlers) {
		this.handlers = handlers;
	}
	get active() {
		return !this.closed && this.ws?.readyState === WebSocket.OPEN;
	}
	sample(into) {
		const mic = this.micAnalyser;
		const out = this.outAnalyser;
		if (!mic && !out) return false;
		const size = into.length;
		const micBins = new Uint8Array(new ArrayBuffer(size));
		const outBins = new Uint8Array(new ArrayBuffer(size));
		mic?.getByteTimeDomainData(micBins);
		out?.getByteTimeDomainData(outBins);
		let energyA = 0;
		let energyB = 0;
		for (let i = 0; i < size; i++) {
			energyA += Math.abs(micBins[i] - 128);
			energyB += Math.abs(outBins[i] - 128);
		}
		into.set(energyB > energyA ? outBins : micBins);
		return true;
	}
	setVolume(volume) {
		if (this.gain) this.gain.gain.value = volume;
	}
	async start(opts) {
		this.stop();
		this.closed = false;
		this.ready = false;
		this.ctx = new AudioContext();
		await this.ctx.resume();
		this.outAnalyser = this.ctx.createAnalyser();
		this.outAnalyser.fftSize = 2048;
		this.gain = this.ctx.createGain();
		this.gain.gain.value = opts.volume;
		this.outAnalyser.connect(this.gain).connect(this.ctx.destination);
		this.stream = await navigator.mediaDevices.getUserMedia({ audio: {
			channelCount: 1,
			echoCancellation: true,
			noiseSuppression: true,
			autoGainControl: true
		} });
		const ws = new WebSocket("wss://api.x.ai/v1/realtime?model=grok-voice-latest", [`xai-client-secret.${opts.token}`]);
		this.ws = ws;
		ws.binaryType = "arraybuffer";
		await new Promise((resolve, reject) => {
			const fail = () => reject(/* @__PURE__ */ new Error("The live voice line could not connect."));
			ws.addEventListener("open", () => resolve(), { once: true });
			ws.addEventListener("error", fail, { once: true });
			window.setTimeout(fail, 12e3);
		});
		ws.onmessage = (event) => {
			if (typeof event.data !== "string") return;
			this.onMessage(event.data);
		};
		ws.onerror = () => {
			if (!this.closed) this.handlers.onError("The live voice connection dropped.");
		};
		ws.onclose = () => {
			this.ready = false;
		};
		const hint = opts.language === "ne" ? "ne" : opts.language;
		ws.send(JSON.stringify({
			type: "session.update",
			session: {
				voice: opts.voiceId,
				instructions: `You are NOVA inside NOVA AI Studio. Reply only in ${LANG_NAME[opts.language]}. ${STYLE_NOTE[opts.style]} Keep each reply to two or four spoken sentences. No markdown.`,
				turn_detection: { type: "server_vad" },
				reasoning: { effort: "none" },
				audio: {
					input: {
						format: {
							type: "audio/pcm",
							rate: 24e3
						},
						transcription: {
							model: "grok-transcribe",
							language_hint: hint
						}
					},
					output: {
						format: {
							type: "audio/pcm",
							rate: 24e3
						},
						speed: Math.min(1.5, Math.max(.7, opts.speed))
					}
				}
			}
		}));
		const source = this.ctx.createMediaStreamSource(this.stream);
		this.micAnalyser = this.ctx.createAnalyser();
		this.micAnalyser.fftSize = 2048;
		this.processor = this.ctx.createScriptProcessor(4096, 1, 1);
		source.connect(this.processor);
		this.processor.connect(this.micAnalyser);
		this.processor.onaudioprocess = (event) => this.onMic(event);
		window.setTimeout(() => {
			if (!this.closed) this.ready = true;
		}, 800);
		this.handlers.onPhase("listening");
	}
	sendText(text) {
		if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
		this.ws.send(JSON.stringify({
			type: "conversation.item.create",
			item: {
				type: "message",
				role: "user",
				content: [{
					type: "input_text",
					text
				}]
			}
		}));
		this.ws.send(JSON.stringify({ type: "response.create" }));
		this.handlers.onUser(`typed-${Date.now()}`, text);
	}
	interrupt() {
		this.stopPlayback();
		this.playbackUntil = 0;
		if (this.ws?.readyState === WebSocket.OPEN) {
			this.ws.send(JSON.stringify({ type: "response.cancel" }));
			this.ws.send(JSON.stringify({ type: "input_audio_buffer.clear" }));
		}
		this.handlers.onPhase("listening");
	}
	stop() {
		this.closed = true;
		this.ready = false;
		this.processor?.disconnect();
		this.processor = null;
		this.stream?.getTracks().forEach((track) => track.stop());
		this.stream = null;
		this.stopPlayback();
		if (this.ws && this.ws.readyState < WebSocket.CLOSING) this.ws.close();
		this.ws = null;
		this.ctx?.close();
		this.ctx = null;
		this.micAnalyser = null;
		this.outAnalyser = null;
		this.gain = null;
		this.pcmCarry = /* @__PURE__ */ new Int16Array(0);
	}
	stopPlayback() {
		for (const source of this.sources) try {
			source.stop();
		} catch {}
		this.sources = [];
		this.nextTime = 0;
	}
	onMic(event) {
		if (!this.ready || !this.ctx || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
		if (this.ctx.currentTime < this.playbackUntil) return;
		const pcm = floatToPcm16(downsample(event.inputBuffer.getChannelData(0), this.ctx.sampleRate, 24e3));
		const merged = new Int16Array(this.pcmCarry.length + pcm.length);
		merged.set(this.pcmCarry, 0);
		merged.set(pcm, this.pcmCarry.length);
		const frame = 2400;
		let offset = 0;
		while (merged.length - offset >= frame) {
			const slice = merged.subarray(offset, offset + frame);
			const bytes = new Uint8Array(slice.buffer, slice.byteOffset, slice.byteLength);
			const copy = new Uint8Array(bytes.byteLength);
			copy.set(bytes);
			this.ws.send(JSON.stringify({
				type: "input_audio_buffer.append",
				audio: bytesToBase64(copy)
			}));
			offset += frame;
		}
		this.pcmCarry = merged.subarray(offset).slice();
	}
	playPcm(b64) {
		if (!this.ctx || !this.outAnalyser) return;
		const bin = atob(b64);
		const bytes = new Uint8Array(bin.length);
		for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
		const samples = new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
		const audio = this.ctx.createBuffer(1, samples.length, 24e3);
		const channel = audio.getChannelData(0);
		for (let i = 0; i < samples.length; i++) channel[i] = samples[i] / 32768;
		const source = this.ctx.createBufferSource();
		source.buffer = audio;
		source.connect(this.outAnalyser);
		const now = this.ctx.currentTime;
		if (this.nextTime < now + .02) this.nextTime = now + .04;
		source.start(this.nextTime);
		this.nextTime += audio.duration;
		this.playbackUntil = this.nextTime;
		this.sources.push(source);
		this.handlers.onPhase("speaking");
	}
	onMessage(raw) {
		let event;
		try {
			event = JSON.parse(raw);
		} catch {
			return;
		}
		const type = String(event.type ?? "");
		if (type === "session.updated" || type === "session.created") {
			if (type === "session.updated") this.ready = true;
			return;
		}
		if (type === "error") {
			const err = event.error;
			const message = typeof err === "string" ? err : err?.message;
			this.handlers.onError(message || "The live voice session reported an error.");
			return;
		}
		if (type === "input_audio_buffer.speech_started") {
			this.stopPlayback();
			this.playbackUntil = 0;
			this.handlers.onPhase("listening");
			return;
		}
		if (type === "conversation.item.input_audio_transcription.updated") {
			const text = String(event.transcript ?? event.text ?? "").trim();
			const id = String(event.item_id ?? "user");
			if (text) this.handlers.onUser(id, text);
			return;
		}
		if (type === "response.output_audio_transcript.delta" || type === "response.audio_transcript.delta" || type === "response.output_text.delta" || type === "response.text.delta") {
			if (!this.assistantId) this.assistantId = String(event.response_id ?? `nova-${Date.now()}`);
			this.assistantText += String(event.delta ?? "");
			this.handlers.onAssistant(this.assistantId, this.assistantText, false);
			return;
		}
		if (type.endsWith("transcript.done") || type === "response.output_audio_transcript.done") {
			const text = String(event.transcript ?? this.assistantText).trim();
			if (!this.assistantId) this.assistantId = String(event.response_id ?? `nova-${Date.now()}`);
			if (text) {
				this.assistantText = text;
				this.handlers.onAssistant(this.assistantId, text, true);
			}
			return;
		}
		if (type === "response.output_audio.delta" || type === "response.audio.delta") {
			const delta = event.delta;
			if (typeof delta === "string" && delta) this.playPcm(delta);
			return;
		}
		if (type === "response.done" || type === "response.output_audio.done") {
			if (this.assistantId && this.assistantText.trim()) this.handlers.onAssistant(this.assistantId, this.assistantText.trim(), true);
			this.assistantId = "";
			this.assistantText = "";
			window.setTimeout(() => {
				if (this.ctx && this.ctx.currentTime >= this.playbackUntil - .05) this.handlers.onPhase("listening");
			}, 300);
		}
	}
};
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var LANGUAGES$1 = /* @__PURE__ */ new Set([
	"en",
	"hi",
	"ne"
]);
var STYLES$1 = /* @__PURE__ */ new Set([
	"documentary",
	"storytelling",
	"educational",
	"conversational"
]);
var VOICE_IDS = new Set(VOICES.map((voice) => voice.id));
var AUDIO_MIMES = /* @__PURE__ */ new Set([
	"audio/webm",
	"audio/ogg",
	"audio/mpeg",
	"audio/mp3",
	"audio/mp4",
	"audio/wav",
	"audio/x-wav",
	"audio/wave",
	"video/webm"
]);
function clampSpeed(value) {
	if (!Number.isFinite(value)) return 1;
	return Math.min(1.5, Math.max(.7, Math.round(value * 100) / 100));
}
function assertSpeech(input) {
	if (!input || typeof input !== "object") throw new Error("Missing voice request.");
	const data = input;
	const text = typeof data.text === "string" ? data.text.trim() : "";
	if (!text) throw new Error("Enter text to speak.");
	if (text.length > 4e3) throw new Error("Keep a generation under 4,000 characters.");
	const voiceId = typeof data.voiceId === "string" ? data.voiceId : "";
	if (!VOICE_IDS.has(voiceId)) throw new Error("Choose a supported voice.");
	const language = data.language;
	if (language !== "en" && language !== "hi" && language !== "ne") throw new Error("Choose English, Hindi, or Nepali.");
	const style = data.style;
	if (typeof style !== "string" || !STYLES$1.has(style)) throw new Error("Choose a narration style.");
	return {
		text,
		voiceId,
		language,
		speed: clampSpeed(typeof data.speed === "number" ? data.speed : Number(data.speed)),
		style
	};
}
function cleanHistory(value) {
	if (!Array.isArray(value)) return [];
	const turns = [];
	for (const item of value.slice(-8)) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		if (row.role !== "user" && row.role !== "assistant") continue;
		if (typeof row.content !== "string") continue;
		const content = row.content.trim().slice(0, 2e3);
		if (!content) continue;
		turns.push({
			role: row.role,
			content
		});
	}
	return turns;
}
var synthesizeSpeech = createServerFn({ method: "POST" }).validator((input) => assertSpeech(input)).handler(createSsrRpc("9811a5c2d3cb151df62f5f712f7f9948149a06c5aebfd46fbe07648a8926a9d1"));
var createVoiceSession = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") return {};
	return input;
}).handler(createSsrRpc("ba9a85fe51c5474412ce86cb991ef1389dfaa169108a59be7aa48c911a535f3a"));
var speakTurn = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing conversation turn.");
	const data = input;
	const speech = assertSpeech({
		text: typeof data.text === "string" && data.text.trim() ? data.text : "turn",
		voiceId: data.voiceId,
		language: data.language,
		speed: data.speed,
		style: data.style
	});
	const text = typeof data.text === "string" ? data.text.trim() : "";
	const audioBase64 = typeof data.audioBase64 === "string" ? data.audioBase64 : "";
	const mime = typeof data.mime === "string" ? data.mime.split(";")[0].trim().toLowerCase() : "";
	if (!text && !audioBase64) throw new Error("Record or type something first.");
	if (audioBase64 && !AUDIO_MIMES.has(mime)) throw new Error("That recording format is not supported.");
	if (!LANGUAGES$1.has(speech.language)) throw new Error("Choose English, Hindi, or Nepali.");
	return {
		speech,
		text,
		audioBase64,
		mime,
		history: cleanHistory(data.history)
	};
}).handler(createSsrRpc("830a0416334c9ea69a182408dc9ec5621dce7f3a63aa26f04f090fc3b0f80391"));
function Waveform({ active, sample }) {
	const canvasRef = (0, import_react.useRef)(null);
	const activeRef = (0, import_react.useRef)(active);
	const sampleRef = (0, import_react.useRef)(sample);
	activeRef.current = active;
	sampleRef.current = sample;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const bins = new Uint8Array(/* @__PURE__ */ new ArrayBuffer(96));
		let raf = 0;
		const draw = (time) => {
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const width = Math.max(1, Math.floor(rect.width * dpr));
			const height = Math.max(1, Math.floor(rect.height * dpr));
			if (canvas.width !== width || canvas.height !== height) {
				canvas.width = width;
				canvas.height = height;
			}
			ctx.clearRect(0, 0, width, height);
			const live = Boolean(activeRef.current && sampleRef.current?.(bins));
			const count = 64;
			const gap = width * .008;
			const bar = (width - gap * 63) / count;
			const mid = height / 2;
			for (let i = 0; i < count; i++) {
				let amp;
				if (live) {
					const raw = bins[Math.floor(i / count * bins.length)] ?? 128;
					amp = Math.min(1, Math.abs(raw - 128) / 72);
				} else if (reduce) amp = .08;
				else amp = .08 + Math.abs(Math.sin(time / 700 + i * .28)) * .12;
				const h = Math.max(2 * dpr, amp * height * .86);
				ctx.fillStyle = live ? "#e6ebf1" : "#3a3a42";
				ctx.fillRect(i * (bar + gap), mid - h / 2, bar, h);
			}
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "panel overflow-hidden p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "h-24 w-full sm:h-28",
			role: "img",
			"aria-label": "Audio waveform"
		})
	});
}
function usePreviewGraph(volume) {
	const graph = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (graph.current) graph.current.gain.gain.value = volume;
	}, [volume]);
	(0, import_react.useEffect)(() => {
		return () => {
			graph.current?.ctx.close();
		};
	}, []);
	return {
		bind: (0, import_react.useCallback)((audio) => {
			if (!graph.current) {
				const ctx = new AudioContext();
				const analyser = ctx.createAnalyser();
				analyser.fftSize = 2048;
				const gain = ctx.createGain();
				gain.gain.value = volume;
				analyser.connect(gain).connect(ctx.destination);
				graph.current = {
					ctx,
					analyser,
					gain,
					bound: /* @__PURE__ */ new WeakSet()
				};
			}
			graph.current.ctx.resume();
			graph.current.gain.gain.value = volume;
			if (!graph.current.bound.has(audio)) {
				graph.current.ctx.createMediaElementSource(audio).connect(graph.current.analyser);
				graph.current.bound.add(audio);
			}
		}, [volume]),
		setActive,
		sample: (0, import_react.useCallback)((bins) => {
			if (!graph.current) return false;
			graph.current.analyser.getByteTimeDomainData(bins);
			return true;
		}, []),
		active
	};
}
function micMessage(err) {
	if (err instanceof DOMException && (err.name === "NotAllowedError" || err.name === "SecurityError")) return "Microphone permission was blocked. Allow the microphone for this site, then start again.";
	if (err instanceof DOMException && err.name === "NotFoundError") return "No microphone was found on this device.";
	return err instanceof Error ? err.message : "Could not open the microphone.";
}
function ConversationPanel({ settings }) {
	const [lines, setLines] = (0, import_react.useState)([]);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [live, setLive] = (0, import_react.useState)(false);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const session = (0, import_react.useRef)(null);
	const history = (0, import_react.useRef)([]);
	const recorder = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const recTimer = (0, import_react.useRef)(0);
	const audioRef = (0, import_react.useRef)(null);
	const preview = usePreviewGraph(settings.volume);
	const settingsRef = (0, import_react.useRef)(settings);
	const recAnalyser = (0, import_react.useRef)(null);
	settingsRef.current = settings;
	(0, import_react.useEffect)(() => {
		session.current?.setVolume(settings.volume);
	}, [settings.volume]);
	function upsert(id, role, text) {
		setLines((current) => {
			const index = current.findIndex((line) => line.id === id);
			if (index === -1) return [...current, {
				id,
				role,
				text
			}];
			const next = current.slice();
			next[index] = {
				...next[index],
				text
			};
			return next;
		});
	}
	async function startLive() {
		setError("");
		setPhase("working");
		try {
			const secret = await createVoiceSession({ data: {} });
			if (!secret.ok) {
				setError(secret.error);
				setPhase("idle");
				return;
			}
			const current = settingsRef.current;
			const liveSession = new LiveVoiceSession({
				onUser: (id, text) => upsert(id, "user", text),
				onAssistant: (id, text) => upsert(id, "assistant", text),
				onError: (message) => setError(message),
				onPhase: (next) => setPhase(next)
			});
			session.current = liveSession;
			liveSession.setVolume(current.volume);
			await liveSession.start({
				token: secret.token,
				voiceId: current.voiceId,
				language: current.language,
				speed: current.speed,
				style: current.style,
				volume: current.volume
			});
			setLive(true);
		} catch (err) {
			session.current?.stop();
			session.current = null;
			setLive(false);
			setPhase("idle");
			setError(micMessage(err));
		}
	}
	function stopLive() {
		session.current?.stop();
		session.current = null;
		setLive(false);
		setPhase("idle");
	}
	function interrupt() {
		session.current?.interrupt();
	}
	async function sendDraft() {
		const text = draft.trim();
		if (!text) return;
		setDraft("");
		if (session.current?.active) {
			session.current.sendText(text);
			return;
		}
		await runTurn({ text });
	}
	async function runTurn(input) {
		setPhase("working");
		setError("");
		const current = settingsRef.current;
		try {
			const result = await speakTurn({ data: {
				text: input.text ?? "",
				audioBase64: input.audioBase64 ?? "",
				mime: input.mime ?? "",
				voiceId: current.voiceId,
				language: current.language,
				speed: current.speed,
				style: current.style,
				history: history.current
			} });
			if (result.userText) {
				upsert(`user-${Date.now()}`, "user", result.userText);
				history.current = [...history.current, {
					role: "user",
					content: result.userText
				}].slice(-8);
			}
			if (result.replyText) {
				upsert(`nova-${Date.now()}`, "assistant", result.replyText);
				history.current = [...history.current, {
					role: "assistant",
					content: result.replyText
				}].slice(-8);
			}
			if (!result.ok || !result.audioBase64 || !result.mime) {
				setError(result.error || "The voice reply did not arrive.");
				setPhase("idle");
				return;
			}
			const audio = audioRef.current;
			if (audio) {
				const bytes = Uint8Array.from(atob(result.audioBase64), (char) => char.charCodeAt(0));
				audio.src = URL.createObjectURL(new Blob([bytes], { type: result.mime }));
				preview.bind(audio);
				preview.setActive(true);
				setPhase("speaking");
				await audio.play().catch(() => setPhase("idle"));
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : "The conversation turn failed.");
			setPhase("idle");
		}
	}
	async function toggleRecord() {
		if (live) return;
		if (recorder.current && recorder.current.state === "recording") {
			recorder.current.stop();
			return;
		}
		setError("");
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: {
				echoCancellation: true,
				noiseSuppression: true
			} });
			const mime = [
				"audio/webm;codecs=opus",
				"audio/webm",
				"audio/mp4"
			].find((item) => MediaRecorder.isTypeSupported(item)) ?? "";
			const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
			chunks.current = [];
			rec.ondataavailable = (event) => {
				if (event.data.size) chunks.current.push(event.data);
			};
			rec.onstop = () => {
				stream.getTracks().forEach((track) => track.stop());
				const node = recAnalyser.current;
				if (node) node.context.close();
				recAnalyser.current = null;
				window.clearTimeout(recTimer.current);
				setRecording(false);
				const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
				(async () => {
					if (blob.size < 800) {
						setError("That recording was too short.");
						return;
					}
					await runTurn({
						audioBase64: await blobToBase64(blob),
						mime: blob.type || "audio/webm"
					});
				})();
			};
			recorder.current = rec;
			const ctx = new AudioContext();
			const analyser = ctx.createAnalyser();
			analyser.fftSize = 2048;
			ctx.createMediaStreamSource(stream).connect(analyser);
			recAnalyser.current = analyser;
			rec.start();
			setRecording(true);
			setPhase("listening");
			recTimer.current = window.setTimeout(() => {
				if (rec.state === "recording") rec.stop();
			}, 45e3);
		} catch (err) {
			setError(micMessage(err));
			setPhase("idle");
		}
	}
	const sample = (bins) => {
		if (live && session.current?.sample(bins)) return true;
		if (recording && recAnalyser.current) {
			recAnalyser.current.getByteTimeDomainData(bins);
			return true;
		}
		return preview.sample(bins);
	};
	const waveActive = live || recording || preview.active || phase === "speaking";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {
				active: waveActive,
				sample: waveActive ? sample : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: stopLive,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }), "Stop conversation"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => void startLive(),
						disabled: phase === "working",
						children: [phase === "working" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "motion-spin size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), "Start conversation"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `btn ${recording ? "btn-danger" : "btn-ghost"}`,
						onClick: () => void toggleRecord(),
						disabled: live || phase === "working",
						"aria-pressed": recording,
						children: [recording ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" }), recording ? "Stop and send" : "Record a turn"]
					}),
					live && phase === "speaking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: interrupt,
						children: "Interrupt"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: live ? phase === "speaking" ? "NOVA is speaking" : "Live microphone is open" : recording ? "Listening" : phase === "working" ? "Working" : "Turn-based or live"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Live mode uses a short-lived session token. If the realtime line is unavailable, record a turn and NOVA still transcribes, replies, and speaks."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "panel max-h-80 space-y-3 overflow-auto p-4",
				role: "log",
				"aria-live": "polite",
				children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "The transcript appears here as you speak."
				}) : lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-2 text-faint",
						children: line.role === "user" ? "You" : "NOVA"
					}), line.text]
				}, line.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (event) => {
					event.preventDefault();
					sendDraft();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Message"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft,
						onChange: (event) => setDraft(event.target.value),
						placeholder: "Or type a line for NOVA to speak",
						maxLength: 2e3
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-ghost",
					disabled: !draft.trim() || phase === "working" || recording,
					children: "Send"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				role: "alert",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				className: "w-full",
				controls: true,
				onPlay: () => preview.setActive(true),
				onPause: () => preview.setActive(false),
				onEnded: () => {
					preview.setActive(false);
					setPhase("idle");
				}
			})
		]
	});
}
var LANGUAGES = [
	{
		id: "en",
		label: "English",
		code: "en"
	},
	{
		id: "hi",
		label: "Hindi",
		code: "hi"
	},
	{
		id: "ne",
		label: "Nepali",
		code: "ne"
	}
];
var STYLES = [
	{
		id: "documentary",
		label: "Documentary",
		note: "Measured cinematic pace"
	},
	{
		id: "storytelling",
		label: "Storytelling",
		note: "Pauses between beats"
	},
	{
		id: "educational",
		label: "Educational",
		note: "Clear, normalized speech"
	},
	{
		id: "conversational",
		label: "Conversational",
		note: "Natural back-and-forth"
	}
];
function visibleVoices(gender) {
	return gender === "all" ? VOICES : VOICES.filter((voice) => voice.gender === gender);
}
function VoiceControls({ settings, onChange, showStyle }) {
	const voices = visibleVoices(settings.gender);
	const current = voices.some((voice) => voice.id === settings.voiceId) ? settings.voiceId : voices[0]?.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel space-y-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl leading-none",
				children: "Desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Language, voice, pace, and playback level."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Language"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: settings.language,
					onChange: (event) => onChange({
						...settings,
						language: event.target.value
					}),
					children: LANGUAGES.map((language) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: language.id,
						children: language.label
					}, language.id))
				})]
			}),
			settings.language === "ne" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Hindi and English use official voice codes. Nepali is requested as ne, then automatic detection if the model declines that code."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Voice"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "field",
					value: settings.gender,
					onChange: (event) => {
						const gender = event.target.value;
						const nextVoices = visibleVoices(gender);
						const voiceId = nextVoices.some((voice) => voice.id === settings.voiceId) ? settings.voiceId : nextVoices[0]?.id ?? settings.voiceId;
						onChange({
							...settings,
							gender,
							voiceId
						});
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All voices"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "female",
							children: "Female"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "male",
							children: "Male"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "neutral",
							children: "Neutral"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Voice character"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: current,
					onChange: (event) => onChange({
						...settings,
						voiceId: event.target.value
					}),
					children: voices.map((voice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: voice.id,
						children: [
							voice.name,
							" — ",
							voice.tone
						]
					}, voice.id))
				})]
			}),
			showStyle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Narration style"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: settings.style,
					onChange: (event) => onChange({
						...settings,
						style: event.target.value
					}),
					children: STYLES.map((style) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: style.id,
						children: [
							style.label,
							" — ",
							style.note
						]
					}, style.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "label",
					children: [
						"Speed ",
						settings.speed.toFixed(2),
						"×"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "range",
					type: "range",
					min: .7,
					max: 1.5,
					step: .05,
					value: settings.speed,
					onChange: (event) => onChange({
						...settings,
						speed: Number(event.target.value)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "label",
					children: ["Volume ", Math.round(settings.volume * 100)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "range",
					type: "range",
					min: 0,
					max: 1,
					step: .01,
					value: settings.volume,
					onChange: (event) => onChange({
						...settings,
						volume: Number(event.target.value)
					})
				})]
			})
		]
	});
}
var MAX_SCENES = 8;
var MAX_CHARS = 1600;
function splitLong(text) {
	const parts = [];
	let rest = text.trim();
	while (rest.length > MAX_CHARS) {
		let cut = rest.lastIndexOf(" ", MAX_CHARS);
		if (cut < 400) cut = MAX_CHARS;
		parts.push(rest.slice(0, cut).trim());
		rest = rest.slice(cut).trim();
	}
	if (rest) parts.push(rest);
	return parts;
}
function splitScript(input) {
	const text = input.replace(/\r\n/g, "\n").trim();
	if (!text) return {
		scenes: [],
		truncated: false
	};
	const marked = text.split(/\n+(?=(?:scene\b|#{1,3}\s|INT\.|EXT\.))/i);
	let chunks = marked.length > 1 ? marked : text.split(/\n\s*\n/);
	chunks = chunks.map((chunk) => chunk.trim()).filter(Boolean);
	if (chunks.length === 1 && chunks[0].length > MAX_CHARS) {
		const sentences = chunks[0].split(/(?<=[.!?।])\s+/);
		chunks = sentences.length > 1 ? sentences : chunks;
	}
	const sized = chunks.flatMap((chunk) => chunk.length > MAX_CHARS ? splitLong(chunk) : [chunk]);
	if (sized.length <= MAX_SCENES) return {
		scenes: sized,
		truncated: false
	};
	const head = sized.slice(0, 7);
	const tail = sized.slice(7).join("\n\n");
	const clipped = tail.length > MAX_CHARS ? tail.slice(0, MAX_CHARS).trim() : tail;
	return {
		scenes: [...head, clipped],
		truncated: true
	};
}
function sceneTitle(text, index) {
	return (text.split("\n").map((row) => row.trim()).find(Boolean) ?? `Scene ${index + 1}`).replace(/^#+\s*/, "").slice(0, 72) || `Scene ${index + 1}`;
}
function DocumentaryPanel({ settings }) {
	const [script, setScript] = (0, import_react.useState)("Scene 1\nA river cuts through the valley before dawn.\n\nScene 2\nThe crew waits in silence as the first light reaches the ridge.");
	const [scenes, setScenes] = (0, import_react.useState)([]);
	const [truncated, setTruncated] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [music, setMusic] = (0, import_react.useState)(null);
	const [musicUrl, setMusicUrl] = (0, import_react.useState)(null);
	const [musicLevel, setMusicLevel] = (0, import_react.useState)(.22);
	const [mixing, setMixing] = (0, import_react.useState)(false);
	const audioRef = (0, import_react.useRef)(null);
	const musicRef = (0, import_react.useRef)(null);
	const runId = (0, import_react.useRef)(0);
	const preview = usePreviewGraph(settings.volume);
	(0, import_react.useEffect)(() => {
		if (musicRef.current) musicRef.current.volume = Math.max(0, Math.min(1, musicLevel * settings.volume));
	}, [musicLevel, settings.volume]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (musicUrl) URL.revokeObjectURL(musicUrl);
			scenes.forEach((scene) => {
				if (scene.url) URL.revokeObjectURL(scene.url);
			});
		};
	}, []);
	function stopMusic() {
		if (musicRef.current) musicRef.current.pause();
	}
	async function narrate() {
		const parsed = splitScript(script);
		if (!parsed.scenes.length) {
			setError("Paste a documentary script first.");
			return;
		}
		const id = ++runId.current;
		setTruncated(parsed.truncated);
		setError("");
		setBusy(true);
		const next = parsed.scenes.map((text, index) => ({
			id: `${id}-${index}`,
			title: sceneTitle(text, index),
			text,
			status: "idle"
		}));
		setScenes(next);
		for (let index = 0; index < next.length; index++) {
			if (runId.current !== id) return;
			setScenes((current) => current.map((scene, i) => i === index ? {
				...scene,
				status: "loading"
			} : scene));
			try {
				const result = await synthesizeSpeech({ data: {
					text: next[index].text,
					voiceId: settings.voiceId,
					language: settings.language,
					speed: settings.speed,
					style: settings.style
				} });
				if (runId.current !== id) return;
				if (!result.ok) {
					setScenes((current) => current.map((scene, i) => i === index ? {
						...scene,
						status: "error",
						error: result.error
					} : scene));
					continue;
				}
				const url = audioUrlFromBase64(result.audioBase64, result.mime);
				setScenes((current) => current.map((scene, i) => i === index ? {
					...scene,
					status: "ready",
					audioBase64: result.audioBase64,
					url
				} : scene));
			} catch (err) {
				if (runId.current !== id) return;
				setScenes((current) => current.map((scene, i) => i === index ? {
					...scene,
					status: "error",
					error: err instanceof Error ? err.message : "Scene failed."
				} : scene));
			}
		}
		if (runId.current === id) setBusy(false);
	}
	function playScene(scene) {
		if (!scene.url || !audioRef.current) return;
		audioRef.current.src = scene.url;
		preview.bind(audioRef.current);
		preview.setActive(true);
		audioRef.current.play();
		if (musicRef.current && musicUrl) {
			musicRef.current.currentTime = 0;
			musicRef.current.play().catch(() => void 0);
		}
	}
	async function playAll() {
		const ready = scenes.filter((scene) => scene.url);
		for (const scene of ready) {
			if (!audioRef.current || !scene.url) continue;
			audioRef.current.src = scene.url;
			preview.bind(audioRef.current);
			preview.setActive(true);
			if (musicRef.current && musicUrl && musicRef.current.paused) musicRef.current.play().catch(() => void 0);
			await audioRef.current.play();
			await new Promise((resolve) => {
				const audio = audioRef.current;
				if (!audio) return resolve();
				const done = () => {
					audio.removeEventListener("ended", done);
					audio.removeEventListener("error", done);
					resolve();
				};
				audio.addEventListener("ended", done);
				audio.addEventListener("error", done);
			});
		}
		stopMusic();
		preview.setActive(false);
	}
	function downloadAll() {
		const files = scenes.flatMap((scene, index) => scene.audioBase64 ? [{
			name: `scene-${String(index + 1).padStart(2, "0")}.mp3`,
			data: base64ToBytes(scene.audioBase64)
		}] : []);
		if (!files.length) return;
		downloadBlob(zipStore(files), "nova-documentary-scenes.zip");
	}
	async function downloadMix() {
		const urls = scenes.flatMap((scene) => scene.url ? [scene.url] : []);
		if (!urls.length) return;
		setMixing(true);
		setError("");
		try {
			downloadBlob(await mixNarration(urls, music, settings.volume, music ? musicLevel * settings.volume : 0), music ? "nova-documentary-mix.wav" : "nova-documentary-narration.wav");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not mix the audio.");
		} finally {
			setMixing(false);
		}
	}
	const readyCount = scenes.filter((scene) => scene.status === "ready").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {
				active: preview.active || busy,
				sample: preview.active ? preview.sample : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Documentary script"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "area min-h-52",
					value: script,
					maxLength: 2e4,
					onChange: (event) => setScript(event.target.value),
					placeholder: "Paste the script. Separate scenes with a blank line, or start lines with Scene 1."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-start justify-between gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Background music"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Music stays separate from the narration. It is mixed only in the browser for preview and an optional WAV download."
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "btn btn-ghost",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }),
							music ? music.name : "Add music file",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "sr-only",
								type: "file",
								accept: "audio/*",
								onChange: (event) => {
									const file = event.target.files?.[0] ?? null;
									if (musicUrl) URL.revokeObjectURL(musicUrl);
									setMusic(file);
									setMusicUrl(file ? URL.createObjectURL(file) : null);
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "label",
							children: ["Music level ", Math.round(musicLevel * 100)]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "range",
							type: "range",
							min: 0,
							max: 1,
							step: .01,
							value: musicLevel,
							onChange: (event) => setMusicLevel(Number(event.target.value))
						})]
					}),
					musicUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
						ref: musicRef,
						src: musicUrl,
						controls: true,
						className: "w-full"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
						ref: musicRef,
						className: "hidden"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => void narrate(),
						disabled: busy || !script.trim(),
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "motion-spin size-4 animate-spin" }) : null, busy ? "Narrating scenes" : "Generate narration"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => void playAll(),
						disabled: !readyCount || busy,
						children: "Preview all"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: downloadAll,
						disabled: !readyCount,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download scenes"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => void downloadMix(),
						disabled: !readyCount || mixing,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), mixing ? "Mixing" : music ? "Download mix WAV" : "Download narration WAV"]
					}),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: () => {
							runId.current += 1;
							setBusy(false);
						},
						children: "Stop"
					}) : null
				]
			}),
			truncated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "The script was longer than 8 scenes. The last scene was shortened so the narration stays bounded."
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				role: "alert",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-3",
				children: scenes.map((scene, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "panel p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-faint",
								children: ["Scene ", index + 1]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: scene.title
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									disabled: scene.status !== "ready",
									onClick: () => playScene(scene),
									children: "Preview"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									disabled: !scene.audioBase64,
									onClick: () => scene.audioBase64 && downloadBase64(scene.audioBase64, `scene-${String(index + 1).padStart(2, "0")}.mp3`, "audio/mpeg"),
									children: "MP3"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 line-clamp-3 text-sm text-muted",
							children: scene.text
						}),
						scene.status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Generating this scene…"
						}) : null,
						scene.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-danger",
							role: "alert",
							children: scene.error
						}) : null
					]
				}, scene.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				className: "w-full",
				controls: true,
				onPlay: () => {
					if (audioRef.current) preview.bind(audioRef.current);
					preview.setActive(true);
				},
				onPause: () => {
					preview.setActive(false);
					stopMusic();
				},
				onEnded: () => preview.setActive(false)
			})
		]
	});
}
var SAMPLES = {
	en: "Nova AI Studio. This is a clean narration test, spoken at the pace you set.",
	hi: "नोवा एआई स्टूडियो। यह एक साफ आवाज़ परीक्षण है, जिस गति को आप चुनते हैं उसी पर बोला गया।",
	ne: "नोभा एआई स्टुडियो। यो एउटा सफा आवाज परीक्षण हो, तपाईंले राखेको गतिमा बोलिएको।"
};
function GeneratorPanel({ settings }) {
	const [text, setText] = (0, import_react.useState)(SAMPLES.en);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)(null);
	const [file, setFile] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const audioRef = (0, import_react.useRef)(null);
	const preview = usePreviewGraph(settings.volume);
	(0, import_react.useEffect)(() => {
		return () => {
			if (url) URL.revokeObjectURL(url);
		};
	}, [url]);
	async function generate() {
		setBusy(true);
		setError("");
		setNote("");
		try {
			const result = await synthesizeSpeech({ data: {
				text,
				voiceId: settings.voiceId,
				language: settings.language,
				speed: settings.speed,
				style: settings.style
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			if (url) URL.revokeObjectURL(url);
			const next = audioUrlFromBase64(result.audioBase64, result.mime);
			setUrl(next);
			setFile({
				b64: result.audioBase64,
				name: `nova-${settings.language}-${settings.voiceId}.mp3`
			});
			if (result.languageUsed === "auto") setNote("Spoken with automatic language detection.");
			const audio = audioRef.current;
			if (audio) {
				audio.src = next;
				preview.bind(audio);
				preview.setActive(true);
				await audio.play().catch(() => void 0);
			}
		} catch (err) {
			setError(err instanceof Error ? err.message : "Voice generation failed.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, {
				active: preview.active || busy,
				sample: preview.active ? preview.sample : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "label",
					children: "Text"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "area",
					value: text,
					maxLength: 4e3,
					onChange: (event) => setText(event.target.value),
					placeholder: "Write the line you want spoken."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: () => void generate(),
						disabled: busy || !text.trim(),
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "motion-spin size-4 animate-spin" }) : null, busy ? "Generating voice" : "Generate Voice"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => setText(SAMPLES[settings.language]),
						disabled: busy,
						children: "Sample line"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost",
						disabled: !file,
						onClick: () => file && downloadBase64(file.b64, file.name, "audio/mpeg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download MP3"]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				role: "alert",
				children: error
			}) : null,
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				className: "w-full",
				controls: true,
				src: url ?? void 0,
				onPlay: () => {
					if (audioRef.current) preview.bind(audioRef.current);
					preview.setActive(true);
				},
				onPause: () => preview.setActive(false),
				onEnded: () => preview.setActive(false)
			})
		]
	});
}
var STORAGE_KEY = "nova-voice-settings-v1";
var DEFAULTS = {
	language: "en",
	voiceId: "leo",
	gender: "all",
	style: "documentary",
	speed: 1,
	volume: .9
};
function readSettings() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return DEFAULTS;
		const parsed = JSON.parse(raw);
		const language = parsed.language === "hi" || parsed.language === "ne" ? parsed.language : "en";
		const style = parsed.style === "storytelling" || parsed.style === "educational" || parsed.style === "conversational" ? parsed.style : "documentary";
		const gender = parsed.gender === "female" || parsed.gender === "male" || parsed.gender === "neutral" ? parsed.gender : "all";
		return {
			language,
			voiceId: VOICES.some((voice) => voice.id === parsed.voiceId) ? parsed.voiceId : DEFAULTS.voiceId,
			gender,
			style,
			speed: typeof parsed.speed === "number" ? Math.min(1.5, Math.max(.7, parsed.speed)) : 1,
			volume: typeof parsed.volume === "number" ? Math.min(1, Math.max(0, parsed.volume)) : .9
		};
	} catch {
		return DEFAULTS;
	}
}
function VoiceStudio() {
	const [settings, setSettings] = (0, import_react.useState)(DEFAULTS);
	const [tab, setTab] = (0, import_react.useState)("conversation");
	(0, import_react.useEffect)(() => {
		setSettings(readSettings());
	}, []);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
	}, [settings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.16em] text-muted",
						children: "NOVA AI VOICE STUDIO"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-4xl leading-none sm:text-5xl",
						children: "Speak, narrate, record."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: "Conversation, narration, and scene-by-scene documentary voice. Speech is synthesized and transcribed through the xAI Voice API. The key stays on the server."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				role: "tablist",
				"aria-label": "Voice studio",
				children: [
					["conversation", "Conversation"],
					["generator", "Generator"],
					["documentary", "Documentary"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tab",
					role: "tab",
					"aria-selected": tab === id,
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					role: "tabpanel",
					children: [
						tab === "conversation" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversationPanel, { settings }) : null,
						tab === "generator" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GeneratorPanel, { settings }) : null,
						tab === "documentary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentaryPanel, { settings }) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceControls, {
					settings,
					onChange: setSettings,
					showStyle: true
				})]
			})
		]
	});
}
function VoicePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, {
		active: "voice",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoiceStudio, {})
	});
}
//#endregion
export { VoicePage as component };
