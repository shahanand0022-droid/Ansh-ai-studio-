import { Link } from "@tanstack/react-router";

export function StudioShell({
  active,
  children,
}: {
  active: "studio" | "voice";
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="border-b border-line">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4">
          <Link to="/" className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-lg border border-line bg-subtle" aria-hidden="true">
              <span className="block h-4 w-3 border-l-2 border-r-2 border-accent" />
            </span>
            <span>
              <span className="block text-xs font-medium tracking-[0.16em] text-muted">NOVA</span>
              <span className="block text-sm font-medium leading-none">AI STUDIO</span>
            </span>
          </Link>
          <nav className="flex items-center gap-1" aria-label="Studio">
            <Link
              to="/"
              aria-current={active === "studio" ? "page" : undefined}
              className={`inline-flex h-11 items-center rounded-full px-4 text-sm font-medium ${
                active === "studio" ? "bg-accent text-accent-fg" : "text-muted"
              }`}
            >
              Studio
            </Link>
            <Link
              to="/voice"
              aria-current={active === "voice" ? "page" : undefined}
              className={`inline-flex h-11 items-center rounded-full px-4 text-sm font-medium ${
                active === "voice" ? "bg-accent text-accent-fg" : "text-muted"
              }`}
            >
              Voice Studio
            </Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-8 sm:py-10">{children}</main>
    </div>
  );
}
