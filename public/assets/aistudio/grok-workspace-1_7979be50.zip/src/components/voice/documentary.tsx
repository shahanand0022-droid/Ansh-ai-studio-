import { useEffect, useRef, useState } from "react";
import { Download, LoaderCircle, Upload } from "lucide-react";
import { audioUrlFromBase64, base64ToBytes, downloadBase64, downloadBlob, mixNarration, zipStore } from "@/lib/voice/audio";
import { sceneTitle, splitScript } from "@/lib/voice/scenes";
import { synthesizeSpeech } from "@/lib/voice/server";
import type { StudioSettings } from "@/components/voice/controls";
import { Waveform } from "@/components/voice/waveform";
import { usePreviewGraph } from "@/components/voice/use-preview";

type Scene = {
  id: string;
  title: string;
  text: string;
  status: "idle" | "loading" | "ready" | "error";
  error?: string;
  audioBase64?: string;
  url?: string;
};

export function DocumentaryPanel({ settings }: { settings: StudioSettings }) {
  const [script, setScript] = useState(
    "Scene 1\nA river cuts through the valley before dawn.\n\nScene 2\nThe crew waits in silence as the first light reaches the ridge.",
  );
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [truncated, setTruncated] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [music, setMusic] = useState<File | null>(null);
  const [musicUrl, setMusicUrl] = useState<string | null>(null);
  const [musicLevel, setMusicLevel] = useState(0.22);
  const [mixing, setMixing] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const musicRef = useRef<HTMLAudioElement>(null);
  const runId = useRef(0);
  const preview = usePreviewGraph(settings.volume);

  useEffect(() => {
    if (musicRef.current) musicRef.current.volume = Math.max(0, Math.min(1, musicLevel * settings.volume));
  }, [musicLevel, settings.volume]);

  useEffect(() => {
    return () => {
      if (musicUrl) URL.revokeObjectURL(musicUrl);
      scenes.forEach((scene) => {
        if (scene.url) URL.revokeObjectURL(scene.url);
      });
    };
    // revoke on unmount only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function stopMusic() {
    if (musicRef.current) {
      musicRef.current.pause();
    }
  }

  async function narrate() {
    const parsed = splitScript(script);
    if (!parsed.scenes.length) {
      setError("Paste a documentary script first.");
      return;
    }
    const id = ++runId.current;
    setTruncated(parsed.truncated);
    setError("");
    setBusy(true);
    const next: Scene[] = parsed.scenes.map((text, index) => ({
      id: `${id}-${index}`,
      title: sceneTitle(text, index),
      text,
      status: "idle",
    }));
    setScenes(next);
    for (let index = 0; index < next.length; index++) {
      if (runId.current !== id) return;
      setScenes((current) => current.map((scene, i) => (i === index ? { ...scene, status: "loading" } : scene)));
      try {
        const result = await synthesizeSpeech({
          data: {
            text: next[index].text,
            voiceId: settings.voiceId,
            language: settings.language,
            speed: settings.speed,
            style: settings.style,
          },
        });
        if (runId.current !== id) return;
        if (!result.ok) {
          setScenes((current) =>
            current.map((scene, i) => (i === index ? { ...scene, status: "error", error: result.error } : scene)),
          );
          continue;
        }
        const url = audioUrlFromBase64(result.audioBase64, result.mime);
        setScenes((current) =>
          current.map((scene, i) =>
            i === index ? { ...scene, status: "ready", audioBase64: result.audioBase64, url } : scene,
          ),
        );
      } catch (err) {
        if (runId.current !== id) return;
        setScenes((current) =>
          current.map((scene, i) =>
            i === index
              ? { ...scene, status: "error", error: err instanceof Error ? err.message : "Scene failed." }
              : scene,
          ),
        );
      }
    }
    if (runId.current === id) setBusy(false);
  }

  function playScene(scene: Scene) {
    if (!scene.url || !audioRef.current) return;
    audioRef.current.src = scene.url;
    preview.bind(audioRef.current);
    preview.setActive(true);
    void audioRef.current.play();
    if (musicRef.current && musicUrl) {
      musicRef.current.currentTime = 0;
      void musicRef.current.play().catch(() => undefined);
    }
  }

  async function playAll() {
    const ready = scenes.filter((scene) => scene.url);
    for (const scene of ready) {
      if (!audioRef.current || !scene.url) continue;
      audioRef.current.src = scene.url;
      preview.bind(audioRef.current);
      preview.setActive(true);
      if (musicRef.current && musicUrl && musicRef.current.paused) {
        void musicRef.current.play().catch(() => undefined);
      }
      await audioRef.current.play();
      await new Promise<void>((resolve) => {
        const audio = audioRef.current;
        if (!audio) return resolve();
        const done = () => {
          audio.removeEventListener("ended", done);
          audio.removeEventListener("error", done);
          resolve();
        };
        audio.addEventListener("ended", done);
        audio.addEventListener("error", done);
      });
    }
    stopMusic();
    preview.setActive(false);
  }

  function downloadAll() {
    const files = scenes.flatMap((scene, index) =>
      scene.audioBase64
        ? [{ name: `scene-${String(index + 1).padStart(2, "0")}.mp3`, data: base64ToBytes(scene.audioBase64) }]
        : [],
    );
    if (!files.length) return;
    downloadBlob(zipStore(files), "nova-documentary-scenes.zip");
  }

  async function downloadMix() {
    const urls = scenes.flatMap((scene) => (scene.url ? [scene.url] : []));
    if (!urls.length) return;
    setMixing(true);
    setError("");
    try {
      const wav = await mixNarration(urls, music, settings.volume, music ? musicLevel * settings.volume : 0);
      downloadBlob(wav, music ? "nova-documentary-mix.wav" : "nova-documentary-narration.wav");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not mix the audio.");
    } finally {
      setMixing(false);
    }
  }

  const readyCount = scenes.filter((scene) => scene.status === "ready").length;

  return (
    <div className="space-y-4">
      <Waveform active={preview.active || busy} sample={preview.active ? preview.sample : undefined} />
      <label className="block">
        <span className="label">Documentary script</span>
        <textarea
          className="area min-h-52"
          value={script}
          maxLength={20000}
          onChange={(event) => setScript(event.target.value)}
          placeholder="Paste the script. Separate scenes with a blank line, or start lines with Scene 1."
        />
      </label>
      <div className="panel space-y-3 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-sm font-medium">Background music</h3>
            <p className="mt-1 text-sm text-muted">
              Music stays separate from the narration. It is mixed only in the browser for preview and an optional WAV download.
            </p>
          </div>
        </div>
        <label className="btn btn-ghost">
          <Upload className="size-4" />
          {music ? music.name : "Add music file"}
          <input
            className="sr-only"
            type="file"
            accept="audio/*"
            onChange={(event) => {
              const file = event.target.files?.[0] ?? null;
              if (musicUrl) URL.revokeObjectURL(musicUrl);
              setMusic(file);
              setMusicUrl(file ? URL.createObjectURL(file) : null);
            }}
          />
        </label>
        <label className="block">
          <span className="label">Music level {Math.round(musicLevel * 100)}</span>
          <input
            className="range"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={musicLevel}
            onChange={(event) => setMusicLevel(Number(event.target.value))}
          />
        </label>
        {musicUrl ? <audio ref={musicRef} src={musicUrl} controls className="w-full" /> : <audio ref={musicRef} className="hidden" />}
      </div>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-primary" onClick={() => void narrate()} disabled={busy || !script.trim()}>
          {busy ? <LoaderCircle className="motion-spin size-4 animate-spin" /> : null}
          {busy ? "Narrating scenes" : "Generate narration"}
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => void playAll()} disabled={!readyCount || busy}>
          Preview all
        </button>
        <button type="button" className="btn btn-ghost" onClick={downloadAll} disabled={!readyCount}>
          <Download className="size-4" />
          Download scenes
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => void downloadMix()} disabled={!readyCount || mixing}>
          <Download className="size-4" />
          {mixing ? "Mixing" : music ? "Download mix WAV" : "Download narration WAV"}
        </button>
        {busy ? (
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              runId.current += 1;
              setBusy(false);
            }}
          >
            Stop
          </button>
        ) : null}
      </div>
      {truncated ? (
        <p className="text-sm text-muted">The script was longer than 8 scenes. The last scene was shortened so the narration stays bounded.</p>
      ) : null}
      {error ? (
        <p className="text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      <ol className="space-y-3">
        {scenes.map((scene, index) => (
          <li key={scene.id} className="panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs text-faint">Scene {index + 1}</p>
                <h3 className="font-medium">{scene.title}</h3>
              </div>
              <div className="flex gap-2">
                <button type="button" className="btn btn-ghost" disabled={scene.status !== "ready"} onClick={() => playScene(scene)}>
                  Preview
                </button>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={!scene.audioBase64}
                  onClick={() =>
                    scene.audioBase64 &&
                    downloadBase64(scene.audioBase64, `scene-${String(index + 1).padStart(2, "0")}.mp3`, "audio/mpeg")
                  }
                >
                  MP3
                </button>
              </div>
            </div>
            <p className="mt-2 line-clamp-3 text-sm text-muted">{scene.text}</p>
            {scene.status === "loading" ? <p className="mt-2 text-sm text-muted">Generating this scene…</p> : null}
            {scene.status === "error" ? (
              <p className="mt-2 text-sm text-danger" role="alert">
                {scene.error}
              </p>
            ) : null}
          </li>
        ))}
      </ol>
      <audio
        ref={audioRef}
        className="w-full"
        controls
        onPlay={() => {
          if (audioRef.current) preview.bind(audioRef.current);
          preview.setActive(true);
        }}
        onPause={() => {
          preview.setActive(false);
          stopMusic();
        }}
        onEnded={() => preview.setActive(false)}
      />
    </div>
  );
}
