import { useEffect, useRef, useState } from "react";
import { LoaderCircle, Mic, Square } from "lucide-react";
import { blobToBase64 } from "@/lib/voice/audio";
import { LiveVoiceSession } from "@/lib/voice/live";
import { createVoiceSession, speakTurn } from "@/lib/voice/server";
import type { ChatTurn } from "@/lib/voice/types";
import type { StudioSettings } from "@/components/voice/controls";
import { Waveform } from "@/components/voice/waveform";
import { usePreviewGraph } from "@/components/voice/use-preview";

type Line = { id: string; role: "user" | "assistant"; text: string };

function micMessage(err: unknown): string {
  if (err instanceof DOMException && (err.name === "NotAllowedError" || err.name === "SecurityError")) {
    return "Microphone permission was blocked. Allow the microphone for this site, then start again.";
  }
  if (err instanceof DOMException && err.name === "NotFoundError") {
    return "No microphone was found on this device.";
  }
  return err instanceof Error ? err.message : "Could not open the microphone.";
}

export function ConversationPanel({ settings }: { settings: StudioSettings }) {
  const [lines, setLines] = useState<Line[]>([]);
  const [phase, setPhase] = useState<"idle" | "listening" | "speaking" | "working">("idle");
  const [live, setLive] = useState(false);
  const [recording, setRecording] = useState(false);
  const [error, setError] = useState("");
  const [draft, setDraft] = useState("");
  const session = useRef<LiveVoiceSession | null>(null);
  const history = useRef<ChatTurn[]>([]);
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const recTimer = useRef<number>(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  const preview = usePreviewGraph(settings.volume);
  const settingsRef = useRef(settings);
  const recAnalyser = useRef<AnalyserNode | null>(null);
  settingsRef.current = settings;

  useEffect(() => {
    session.current?.setVolume(settings.volume);
  }, [settings.volume]);

  function upsert(id: string, role: Line["role"], text: string) {
    setLines((current) => {
      const index = current.findIndex((line) => line.id === id);
      if (index === -1) return [...current, { id, role, text }];
      const next = current.slice();
      next[index] = { ...next[index], text };
      return next;
    });
  }

  async function startLive() {
    setError("");
    setPhase("working");
    try {
      const secret = await createVoiceSession({ data: {} });
      if (!secret.ok) {
        setError(secret.error);
        setPhase("idle");
        return;
      }
      const current = settingsRef.current;
      const liveSession = new LiveVoiceSession({
        onUser: (id, text) => upsert(id, "user", text),
        onAssistant: (id, text) => upsert(id, "assistant", text),
        onError: (message) => setError(message),
        onPhase: (next) => setPhase(next),
      });
      session.current = liveSession;
      liveSession.setVolume(current.volume);
      await liveSession.start({
        token: secret.token,
        voiceId: current.voiceId,
        language: current.language,
        speed: current.speed,
        style: current.style,
        volume: current.volume,
      });
      setLive(true);
    } catch (err) {
      session.current?.stop();
      session.current = null;
      setLive(false);
      setPhase("idle");
      setError(micMessage(err));
    }
  }

  function stopLive() {
    session.current?.stop();
    session.current = null;
    setLive(false);
    setPhase("idle");
  }

  function interrupt() {
    session.current?.interrupt();
  }

  async function sendDraft() {
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    if (session.current?.active) {
      session.current.sendText(text);
      return;
    }
    await runTurn({ text });
  }

  async function runTurn(input: { text?: string; audioBase64?: string; mime?: string }) {
    setPhase("working");
    setError("");
    const current = settingsRef.current;
    try {
      const result = await speakTurn({
        data: {
          text: input.text ?? "",
          audioBase64: input.audioBase64 ?? "",
          mime: input.mime ?? "",
          voiceId: current.voiceId,
          language: current.language,
          speed: current.speed,
          style: current.style,
          history: history.current,
        },
      });
      if (result.userText) {
        upsert(`user-${Date.now()}`, "user", result.userText);
        history.current = [...history.current, { role: "user" as const, content: result.userText }].slice(-8);
      }
      if (result.replyText) {
        upsert(`nova-${Date.now()}`, "assistant", result.replyText);
        history.current = [...history.current, { role: "assistant" as const, content: result.replyText }].slice(-8);
      }
      if (!result.ok || !result.audioBase64 || !result.mime) {
        setError(result.error || "The voice reply did not arrive.");
        setPhase("idle");
        return;
      }
      const audio = audioRef.current;
      if (audio) {
        const bytes = Uint8Array.from(atob(result.audioBase64), (char) => char.charCodeAt(0));
        const url = URL.createObjectURL(new Blob([bytes], { type: result.mime }));
        audio.src = url;
        preview.bind(audio);
        preview.setActive(true);
        setPhase("speaking");
        await audio.play().catch(() => setPhase("idle"));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "The conversation turn failed.");
      setPhase("idle");
    }
  }

  async function toggleRecord() {
    if (live) return;
    if (recorder.current && recorder.current.state === "recording") {
      recorder.current.stop();
      return;
    }
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      });
      const preferred = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
      const mime = preferred.find((item) => MediaRecorder.isTypeSupported(item)) ?? "";
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (event) => {
        if (event.data.size) chunks.current.push(event.data);
      };
      rec.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const node = recAnalyser.current;
        if (node) void (node.context as AudioContext).close();
        recAnalyser.current = null;
        window.clearTimeout(recTimer.current);
        setRecording(false);
        const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
        void (async () => {
          if (blob.size < 800) {
            setError("That recording was too short.");
            return;
          }
          const audioBase64 = await blobToBase64(blob);
          await runTurn({ audioBase64, mime: blob.type || "audio/webm" });
        })();
      };
      recorder.current = rec;
      const ctx = new AudioContext();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 2048;
      ctx.createMediaStreamSource(stream).connect(analyser);
      recAnalyser.current = analyser;
      rec.start();
      setRecording(true);
      setPhase("listening");
      recTimer.current = window.setTimeout(() => {
        if (rec.state === "recording") rec.stop();
      }, 45000);
    } catch (err) {
      setError(micMessage(err));
      setPhase("idle");
    }
  }

  const sample = (bins: Uint8Array<ArrayBuffer>) => {
    if (live && session.current?.sample(bins)) return true;
    if (recording && recAnalyser.current) {
      recAnalyser.current.getByteTimeDomainData(bins);
      return true;
    }
    return preview.sample(bins);
  };
  const waveActive = live || recording || preview.active || phase === "speaking";

  return (
    <div className="space-y-4">
      <Waveform active={waveActive} sample={waveActive ? sample : undefined} />
      <div className="flex flex-wrap items-center gap-2">
        {live ? (
          <button type="button" className="btn btn-danger" onClick={stopLive}>
            <Square className="size-4" />
            Stop conversation
          </button>
        ) : (
          <button type="button" className="btn btn-primary" onClick={() => void startLive()} disabled={phase === "working"}>
            {phase === "working" ? <LoaderCircle className="motion-spin size-4 animate-spin" /> : <Mic className="size-4" />}
            Start conversation
          </button>
        )}
        <button
          type="button"
          className={`btn ${recording ? "btn-danger" : "btn-ghost"}`}
          onClick={() => void toggleRecord()}
          disabled={live || phase === "working"}
          aria-pressed={recording}
        >
          {recording ? <Square className="size-4" /> : <Mic className="size-4" />}
          {recording ? "Stop and send" : "Record a turn"}
        </button>
        {live && phase === "speaking" ? (
          <button type="button" className="btn btn-ghost" onClick={interrupt}>
            Interrupt
          </button>
        ) : null}
        <span className="text-sm text-muted">
          {live
            ? phase === "speaking"
              ? "NOVA is speaking"
              : "Live microphone is open"
            : recording
              ? "Listening"
              : phase === "working"
                ? "Working"
                : "Turn-based or live"}
        </span>
      </div>
      <p className="text-sm text-muted">
        Live mode uses a short-lived session token. If the realtime line is unavailable, record a turn and NOVA still transcribes, replies, and speaks.
      </p>
      <div className="panel max-h-80 space-y-3 overflow-auto p-4" role="log" aria-live="polite">
        {lines.length === 0 ? (
          <p className="text-sm text-muted">The transcript appears here as you speak.</p>
        ) : (
          lines.map((line) => (
            <p key={line.id} className="text-sm">
              <span className="mr-2 text-faint">{line.role === "user" ? "You" : "NOVA"}</span>
              {line.text}
            </p>
          ))
        )}
      </div>
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          void sendDraft();
        }}
      >
        <label className="min-w-0 flex-1">
          <span className="sr-only">Message</span>
          <input
            className="field"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder="Or type a line for NOVA to speak"
            maxLength={2000}
          />
        </label>
        <button type="submit" className="btn btn-ghost" disabled={!draft.trim() || phase === "working" || recording}>
          Send
        </button>
      </form>
      {error ? (
        <p className="text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      <audio
        ref={audioRef}
        className="w-full"
        controls
        onPlay={() => preview.setActive(true)}
        onPause={() => preview.setActive(false)}
        onEnded={() => {
          preview.setActive(false);
          setPhase("idle");
        }}
      />
    </div>
  );
}
