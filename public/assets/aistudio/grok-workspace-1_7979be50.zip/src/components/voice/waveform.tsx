import { useEffect, useRef } from "react";

export function Waveform({
  active,
  sample,
}: {
  active: boolean;
  sample?: (into: Uint8Array<ArrayBuffer>) => boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const activeRef = useRef(active);
  const sampleRef = useRef(sample);
  activeRef.current = active;
  sampleRef.current = sample;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const bins = new Uint8Array(new ArrayBuffer(96));
    let raf = 0;

    const draw = (time: number) => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.max(1, Math.floor(rect.width * dpr));
      const height = Math.max(1, Math.floor(rect.height * dpr));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      ctx.clearRect(0, 0, width, height);
      const live = Boolean(activeRef.current && sampleRef.current?.(bins));
      const count = 64;
      const gap = width * 0.008;
      const bar = (width - gap * (count - 1)) / count;
      const mid = height / 2;
      for (let i = 0; i < count; i++) {
        let amp: number;
        if (live) {
          const raw = bins[Math.floor((i / count) * bins.length)] ?? 128;
          amp = Math.min(1, Math.abs(raw - 128) / 72);
        } else if (reduce) {
          amp = 0.08;
        } else {
          amp = 0.08 + Math.abs(Math.sin(time / 700 + i * 0.28)) * 0.12;
        }
        const h = Math.max(2 * dpr, amp * height * 0.86);
        ctx.fillStyle = live ? "#e6ebf1" : "#3a3a42";
        ctx.fillRect(i * (bar + gap), mid - h / 2, bar, h);
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="panel overflow-hidden p-3">
      <canvas ref={canvasRef} className="h-24 w-full sm:h-28" role="img" aria-label="Audio waveform" />
    </div>
  );
}
