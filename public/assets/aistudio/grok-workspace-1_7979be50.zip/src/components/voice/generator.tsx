import { useEffect, useRef, useState } from "react";
import { Download, LoaderCircle } from "lucide-react";
import { audioUrlFromBase64, downloadBase64 } from "@/lib/voice/audio";
import { synthesizeSpeech } from "@/lib/voice/server";
import type { VoiceLanguage } from "@/lib/voice/types";
import type { StudioSettings } from "@/components/voice/controls";
import { Waveform } from "@/components/voice/waveform";
import { usePreviewGraph } from "@/components/voice/use-preview";

const SAMPLES: Record<VoiceLanguage, string> = {
  en: "Nova AI Studio. This is a clean narration test, spoken at the pace you set.",
  hi: "नोवा एआई स्टूडियो। यह एक साफ आवाज़ परीक्षण है, जिस गति को आप चुनते हैं उसी पर बोला गया।",
  ne: "नोभा एआई स्टुडियो। यो एउटा सफा आवाज परीक्षण हो, तपाईंले राखेको गतिमा बोलिएको।",
};

export function GeneratorPanel({ settings }: { settings: StudioSettings }) {
  const [text, setText] = useState(SAMPLES.en);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [url, setUrl] = useState<string | null>(null);
  const [file, setFile] = useState<{ b64: string; name: string } | null>(null);
  const [note, setNote] = useState("");
  const audioRef = useRef<HTMLAudioElement>(null);
  const preview = usePreviewGraph(settings.volume);

  useEffect(() => {
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [url]);

  async function generate() {
    setBusy(true);
    setError("");
    setNote("");
    try {
      const result = await synthesizeSpeech({
        data: {
          text,
          voiceId: settings.voiceId,
          language: settings.language,
          speed: settings.speed,
          style: settings.style,
        },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      if (url) URL.revokeObjectURL(url);
      const next = audioUrlFromBase64(result.audioBase64, result.mime);
      setUrl(next);
      setFile({ b64: result.audioBase64, name: `nova-${settings.language}-${settings.voiceId}.mp3` });
      if (result.languageUsed === "auto") setNote("Spoken with automatic language detection.");
      const audio = audioRef.current;
      if (audio) {
        audio.src = next;
        preview.bind(audio);
        preview.setActive(true);
        await audio.play().catch(() => undefined);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Voice generation failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <Waveform active={preview.active || busy} sample={preview.active ? preview.sample : undefined} />
      <label className="block">
        <span className="label">Text</span>
        <textarea
          className="area"
          value={text}
          maxLength={4000}
          onChange={(event) => setText(event.target.value)}
          placeholder="Write the line you want spoken."
        />
      </label>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-primary" onClick={() => void generate()} disabled={busy || !text.trim()}>
          {busy ? <LoaderCircle className="motion-spin size-4 animate-spin" /> : null}
          {busy ? "Generating voice" : "Generate Voice"}
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => setText(SAMPLES[settings.language])} disabled={busy}>
          Sample line
        </button>
        <button
          type="button"
          className="btn btn-ghost"
          disabled={!file}
          onClick={() => file && downloadBase64(file.b64, file.name, "audio/mpeg")}
        >
          <Download className="size-4" />
          Download MP3
        </button>
      </div>
      {error ? (
        <p className="text-sm text-danger" role="alert">
          {error}
        </p>
      ) : null}
      {note ? <p className="text-sm text-muted">{note}</p> : null}
      <audio
        ref={audioRef}
        className="w-full"
        controls
        src={url ?? undefined}
        onPlay={() => {
          if (audioRef.current) preview.bind(audioRef.current);
          preview.setActive(true);
        }}
        onPause={() => preview.setActive(false)}
        onEnded={() => preview.setActive(false)}
      />
    </div>
  );
}
