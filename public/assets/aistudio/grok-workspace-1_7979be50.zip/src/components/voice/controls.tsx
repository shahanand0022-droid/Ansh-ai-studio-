import { VOICES } from "@/lib/voice/catalog";
import { LANGUAGES, STYLES, type NarrationStyle, type VoiceGender, type VoiceLanguage } from "@/lib/voice/types";

export type StudioSettings = {
  language: VoiceLanguage;
  voiceId: string;
  gender: "all" | VoiceGender;
  style: NarrationStyle;
  speed: number;
  volume: number;
};

export function visibleVoices(gender: StudioSettings["gender"]) {
  return gender === "all" ? VOICES : VOICES.filter((voice) => voice.gender === gender);
}

export function VoiceControls({
  settings,
  onChange,
  showStyle,
}: {
  settings: StudioSettings;
  onChange: (next: StudioSettings) => void;
  showStyle: boolean;
}) {
  const voices = visibleVoices(settings.gender);
  const current = voices.some((voice) => voice.id === settings.voiceId) ? settings.voiceId : voices[0]?.id;

  return (
    <div className="panel space-y-4 p-4">
      <div>
        <h2 className="font-display text-2xl leading-none">Desk</h2>
        <p className="mt-2 text-sm text-muted">Language, voice, pace, and playback level.</p>
      </div>
      <label className="block">
        <span className="label">Language</span>
        <select
          className="field"
          value={settings.language}
          onChange={(event) => onChange({ ...settings, language: event.target.value as VoiceLanguage })}
        >
          {LANGUAGES.map((language) => (
            <option key={language.id} value={language.id}>
              {language.label}
            </option>
          ))}
        </select>
      </label>
      {settings.language === "ne" ? (
        <p className="text-sm text-muted">
          Hindi and English use official voice codes. Nepali is requested as ne, then automatic detection if the model declines that code.
        </p>
      ) : null}
      <label className="block">
        <span className="label">Voice</span>
        <select
          className="field"
          value={settings.gender}
          onChange={(event) => {
            const gender = event.target.value as StudioSettings["gender"];
            const nextVoices = visibleVoices(gender);
            const voiceId = nextVoices.some((voice) => voice.id === settings.voiceId)
              ? settings.voiceId
              : (nextVoices[0]?.id ?? settings.voiceId);
            onChange({ ...settings, gender, voiceId });
          }}
        >
          <option value="all">All voices</option>
          <option value="female">Female</option>
          <option value="male">Male</option>
          <option value="neutral">Neutral</option>
        </select>
      </label>
      <label className="block">
        <span className="label">Voice character</span>
        <select
          className="field"
          value={current}
          onChange={(event) => onChange({ ...settings, voiceId: event.target.value })}
        >
          {voices.map((voice) => (
            <option key={voice.id} value={voice.id}>
              {voice.name} — {voice.tone}
            </option>
          ))}
        </select>
      </label>
      {showStyle ? (
        <label className="block">
          <span className="label">Narration style</span>
          <select
            className="field"
            value={settings.style}
            onChange={(event) => onChange({ ...settings, style: event.target.value as NarrationStyle })}
          >
            {STYLES.map((style) => (
              <option key={style.id} value={style.id}>
                {style.label} — {style.note}
              </option>
            ))}
          </select>
        </label>
      ) : null}
      <label className="block">
        <span className="label">Speed {settings.speed.toFixed(2)}×</span>
        <input
          className="range"
          type="range"
          min={0.7}
          max={1.5}
          step={0.05}
          value={settings.speed}
          onChange={(event) => onChange({ ...settings, speed: Number(event.target.value) })}
        />
      </label>
      <label className="block">
        <span className="label">Volume {Math.round(settings.volume * 100)}</span>
        <input
          className="range"
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={settings.volume}
          onChange={(event) => onChange({ ...settings, volume: Number(event.target.value) })}
        />
      </label>
    </div>
  );
}
