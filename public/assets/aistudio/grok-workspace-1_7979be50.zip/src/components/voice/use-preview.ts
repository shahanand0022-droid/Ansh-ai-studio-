import { useCallback, useEffect, useRef, useState } from "react";

export function usePreviewGraph(volume: number) {
  const graph = useRef<{
    ctx: AudioContext;
    analyser: AnalyserNode;
    gain: GainNode;
    bound: WeakSet<HTMLAudioElement>;
  } | null>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (graph.current) graph.current.gain.gain.value = volume;
  }, [volume]);

  useEffect(() => {
    return () => {
      void graph.current?.ctx.close();
    };
  }, []);

  const bind = useCallback(
    (audio: HTMLAudioElement) => {
      if (!graph.current) {
        const ctx = new AudioContext();
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 2048;
        const gain = ctx.createGain();
        gain.gain.value = volume;
        analyser.connect(gain).connect(ctx.destination);
        graph.current = { ctx, analyser, gain, bound: new WeakSet() };
      }
      void graph.current.ctx.resume();
      graph.current.gain.gain.value = volume;
      if (!graph.current.bound.has(audio)) {
        const source = graph.current.ctx.createMediaElementSource(audio);
        source.connect(graph.current.analyser);
        graph.current.bound.add(audio);
      }
    },
    [volume],
  );

  const sample = useCallback((bins: Uint8Array<ArrayBuffer>) => {
    if (!graph.current) return false;
    graph.current.analyser.getByteTimeDomainData(bins);
    return true;
  }, []);

  return { bind, setActive, sample, active };
}
