import { useEffect, useState } from "react";
import { VOICES } from "@/lib/voice/catalog";
import { ConversationPanel } from "@/components/voice/conversation";
import { VoiceControls, type StudioSettings } from "@/components/voice/controls";
import { DocumentaryPanel } from "@/components/voice/documentary";
import { GeneratorPanel } from "@/components/voice/generator";

const STORAGE_KEY = "nova-voice-settings-v1";

const DEFAULTS: StudioSettings = {
  language: "en",
  voiceId: "leo",
  gender: "all",
  style: "documentary",
  speed: 1,
  volume: 0.9,
};

type Tab = "conversation" | "generator" | "documentary";

function readSettings(): StudioSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULTS;
    const parsed = JSON.parse(raw) as Partial<StudioSettings>;
    const language = parsed.language === "hi" || parsed.language === "ne" ? parsed.language : "en";
    const style =
      parsed.style === "storytelling" || parsed.style === "educational" || parsed.style === "conversational"
        ? parsed.style
        : "documentary";
    const gender =
      parsed.gender === "female" || parsed.gender === "male" || parsed.gender === "neutral" ? parsed.gender : "all";
    const voiceId = VOICES.some((voice) => voice.id === parsed.voiceId) ? parsed.voiceId! : DEFAULTS.voiceId;
    const speed = typeof parsed.speed === "number" ? Math.min(1.5, Math.max(0.7, parsed.speed)) : 1;
    const volume = typeof parsed.volume === "number" ? Math.min(1, Math.max(0, parsed.volume)) : 0.9;
    return { language, voiceId, gender, style, speed, volume };
  } catch {
    return DEFAULTS;
  }
}

export function VoiceStudio() {
  const [settings, setSettings] = useState<StudioSettings>(DEFAULTS);
  const [tab, setTab] = useState<Tab>("conversation");

  useEffect(() => {
    setSettings(readSettings());
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  return (
    <div className="space-y-6">
      <div className="max-w-2xl">
        <p className="text-xs font-medium tracking-[0.16em] text-muted">NOVA AI VOICE STUDIO</p>
        <h1 className="font-display mt-2 text-4xl leading-none sm:text-5xl">Speak, narrate, record.</h1>
        <p className="mt-3 text-muted">
          Conversation, narration, and scene-by-scene documentary voice. Speech is synthesized and transcribed through the xAI Voice API. The key stays on the server.
        </p>
      </div>
      <div className="flex gap-2 overflow-x-auto" role="tablist" aria-label="Voice studio">
        {(
          [
            ["conversation", "Conversation"],
            ["generator", "Generator"],
            ["documentary", "Documentary"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className="tab"
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <section role="tabpanel">
          {tab === "conversation" ? <ConversationPanel settings={settings} /> : null}
          {tab === "generator" ? <GeneratorPanel settings={settings} /> : null}
          {tab === "documentary" ? <DocumentaryPanel settings={settings} /> : null}
        </section>
        <VoiceControls settings={settings} onChange={setSettings} showStyle />
      </div>
    </div>
  );
}
