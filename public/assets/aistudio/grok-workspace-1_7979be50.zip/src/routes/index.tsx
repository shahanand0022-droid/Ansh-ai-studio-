import { createFileRoute, Link } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio-shell";

export const Route = createFileRoute("/")({
  component: Home,
});

const DESK = [
  {
    title: "Conversation",
    copy: "Open the microphone for a live voice line, or record a single turn. Speech becomes text, then a spoken reply.",
  },
  {
    title: "Generator",
    copy: "Turn a script into narration in English, Hindi, or Nepali, with female, male, and neutral voices.",
  },
  {
    title: "Documentary",
    copy: "Split a script into scenes, render each one, then lay a music bed beside the voice and download both.",
  },
];

function Home() {
  return (
    <StudioShell active="studio">
      <div className="grid items-end gap-10 lg:grid-cols-[minmax(0,1.4fr)_minmax(16rem,0.8fr)]">
        <div>
          <p className="text-xs font-medium tracking-[0.18em] text-muted">VOICE DESK</p>
          <h1 className="font-display mt-3 max-w-xl text-5xl leading-[1.02] sm:text-6xl">NOVA AI STUDIO</h1>
          <p className="mt-4 max-w-xl text-lg text-muted">
            A quiet room for spoken work. Voice Studio handles live conversation, narration, and documentary scenes without sending the API key to the browser.
          </p>
          <Link to="/voice" className="btn btn-primary mt-6">
            Open Voice Studio
          </Link>
        </div>
        <dl className="panel divide-y divide-line p-5 text-sm">
          <div className="flex justify-between gap-4 py-2">
            <dt className="text-muted">Languages</dt>
            <dd>English, Hindi, Nepali</dd>
          </div>
          <div className="flex justify-between gap-4 py-2">
            <dt className="text-muted">Voices</dt>
            <dd>Female, male, neutral</dd>
          </div>
          <div className="flex justify-between gap-4 py-2">
            <dt className="text-muted">Output</dt>
            <dd>MP3, WAV mix</dd>
          </div>
          <div className="flex justify-between gap-4 py-2">
            <dt className="text-muted">Live line</dt>
            <dd>Realtime where open</dd>
          </div>
        </dl>
      </div>
      <ol className="mt-10 divide-y divide-line border-y border-line">
        {DESK.map((item, index) => (
          <li key={item.title} className="grid gap-2 py-5 sm:grid-cols-[8rem_minmax(0,1fr)] sm:gap-6">
            <p className="text-sm text-faint">0{index + 1}</p>
            <div>
              <h2 className="font-display text-3xl leading-none">{item.title}</h2>
              <p className="mt-2 max-w-2xl text-muted">{item.copy}</p>
            </div>
          </li>
        ))}
      </ol>
    </StudioShell>
  );
}
