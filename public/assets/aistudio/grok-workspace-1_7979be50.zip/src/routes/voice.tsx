import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio-shell";
import { VoiceStudio } from "@/components/voice/voice-studio";

export const Route = createFileRoute("/voice")({
  component: VoicePage,
  head: () => ({
    meta: [{ title: "Voice Studio · NOVA AI STUDIO" }],
  }),
});

function VoicePage() {
  return (
    <StudioShell active="voice">
      <VoiceStudio />
    </StudioShell>
  );
}
