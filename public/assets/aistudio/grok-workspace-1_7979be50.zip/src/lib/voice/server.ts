import { createServerFn } from "@tanstack/react-start";
import { VOICES } from "@/lib/voice/catalog";
import type {
  ChatTurn,
  NarrationStyle,
  SessionResult,
  SpeechResult,
  TurnResult,
  VoiceLanguage,
} from "@/lib/voice/types";

const TTS_URL = "https://api.x.ai/v1/tts";
const STT_URL = "https://api.x.ai/v1/stt";
const CHAT_URL = "https://api.x.ai/v1/chat/completions";
const SECRET_URL = "https://api.x.ai/v1/realtime/client_secrets";

const LANGUAGES = new Set<VoiceLanguage>(["en", "hi", "ne"]);
const STYLES = new Set<NarrationStyle>([
  "documentary",
  "storytelling",
  "educational",
  "conversational",
]);
const VOICE_IDS = new Set(VOICES.map((voice) => voice.id));
const AUDIO_MIMES = new Set([
  "audio/webm",
  "audio/ogg",
  "audio/mpeg",
  "audio/mp3",
  "audio/mp4",
  "audio/wav",
  "audio/x-wav",
  "audio/wave",
  "video/webm",
]);

const STYLE_NOTE: Record<NarrationStyle, string> = {
  documentary: "Speak like a cinematic documentary narrator: measured, vivid, and calm.",
  storytelling: "Speak like a storyteller sitting close to the listener.",
  educational: "Speak like a clear teacher. Explain without rushing.",
  conversational: "Speak like a natural conversation partner. Keep it warm and brief.",
};

const LANG_NAME: Record<VoiceLanguage, string> = {
  en: "English",
  hi: "Hindi",
  ne: "Nepali",
};

type SpeechInput = {
  text: string;
  voiceId: string;
  language: VoiceLanguage;
  speed: number;
  style: NarrationStyle;
};

function apiKey(): string | null {
  const key = process.env.XAI_API_KEY;
  return key && key.trim() ? key : null;
}

function missingKey(): string {
  return "Voice is unavailable because the server has no XAI_API_KEY. The key must stay on the server. It is never entered in the browser.";
}

function readError(status: number, raw: string): string {
  let msg = raw.slice(0, 400);
  try {
    const parsed = JSON.parse(raw) as { error?: unknown; message?: unknown };
    if (typeof parsed.error === "string") msg = parsed.error;
    else if (parsed.error && typeof parsed.error === "object" && "message" in parsed.error) {
      const inner = (parsed.error as { message?: unknown }).message;
      if (typeof inner === "string") msg = inner;
    } else if (typeof parsed.message === "string") msg = parsed.message;
  } catch {
    /* raw text */
  }
  if (/spending-limit|run out of credits|need a grok subscription/i.test(msg)) {
    return "xAI voice credits are blocked for this studio key (spending limit or no credits). Add API credits, then generate again. The key stays on the server.";
  }
  if (status === 401) return "The voice service rejected the server key.";
  if (status === 404) return "That voice is not available. Choose another voice.";
  return msg || `Voice service error (${status}).`;
}

async function xaiFetch(url: string, init: RequestInit): Promise<Response> {
  const first = await fetch(url, init);
  if (first.status !== 429 && first.status !== 503) return first;
  await new Promise((resolve) => setTimeout(resolve, 500));
  return fetch(url, init);
}

function clampSpeed(value: number): number {
  if (!Number.isFinite(value)) return 1;
  return Math.min(1.5, Math.max(0.7, Math.round(value * 100) / 100));
}

function styleText(text: string, style: NarrationStyle): string {
  const clean = text.replace(/\s+\n/g, "\n").trim();
  if (style === "documentary" || style === "storytelling") {
    return clean.replace(/([.!?।])\s+/g, "$1 [pause] ");
  }
  return clean;
}

function assertSpeech(input: unknown): SpeechInput {
  if (!input || typeof input !== "object") throw new Error("Missing voice request.");
  const data = input as Record<string, unknown>;
  const text = typeof data.text === "string" ? data.text.trim() : "";
  if (!text) throw new Error("Enter text to speak.");
  if (text.length > 4000) throw new Error("Keep a generation under 4,000 characters.");
  const voiceId = typeof data.voiceId === "string" ? data.voiceId : "";
  if (!VOICE_IDS.has(voiceId)) throw new Error("Choose a supported voice.");
  const language = data.language;
  if (language !== "en" && language !== "hi" && language !== "ne") {
    throw new Error("Choose English, Hindi, or Nepali.");
  }
  const style = data.style;
  if (typeof style !== "string" || !STYLES.has(style as NarrationStyle)) {
    throw new Error("Choose a narration style.");
  }
  return {
    text,
    voiceId,
    language,
    speed: clampSpeed(typeof data.speed === "number" ? data.speed : Number(data.speed)),
    style: style as NarrationStyle,
  };
}

async function synthesize(input: SpeechInput, key: string): Promise<SpeechResult> {
  const spoken = styleText(input.text, input.style);
  const languages = input.language === "ne" ? ["ne", "auto"] : [input.language];
  let last = "Voice synthesis failed.";
  for (const language of languages) {
    const res = await xaiFetch(TTS_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text: spoken,
        voice_id: input.voiceId,
        language,
        speed: input.speed,
        text_normalization: true,
        output_format: { codec: "mp3", sample_rate: 24000, bit_rate: 128000 },
      }),
    });
    if (res.ok) {
      const bytes = new Uint8Array(await res.arrayBuffer());
      if (bytes.byteLength < 32) return { ok: false, error: "The voice service returned empty audio." };
      return {
        ok: true,
        audioBase64: Buffer.from(bytes).toString("base64"),
        mime: "audio/mpeg",
        languageUsed: language,
      };
    }
    last = readError(res.status, await res.text());
    if (res.status !== 400 || language === languages[languages.length - 1]) break;
  }
  return { ok: false, error: last };
}

function extFor(mime: string): string {
  if (mime.includes("webm")) return "webm";
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("wav")) return "wav";
  return "mp3";
}

async function transcribe(audioBase64: string, mime: string, language: VoiceLanguage, key: string) {
  if (audioBase64.length > 4_500_000) {
    return { ok: false as const, error: "That recording is too long. Keep a turn under about 45 seconds." };
  }
  const bytes = Buffer.from(audioBase64, "base64");
  const form = new FormData();
  form.append("model", "grok-voice-transcribe-2.0");
  if (language !== "ne") form.append("language", language);
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  form.append("file", new Blob([copy]), `turn.${extFor(mime)}`);
  const res = await xaiFetch(STT_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}` },
    body: form,
  });
  if (!res.ok) return { ok: false as const, error: readError(res.status, await res.text()) };
  const body = (await res.json()) as { text?: string; transcript?: string };
  const text = (body.text || body.transcript || "").trim();
  if (!text) return { ok: false as const, error: "No speech was detected. Try again a little closer to the microphone." };
  return { ok: true as const, text };
}

function cleanHistory(value: unknown): ChatTurn[] {
  if (!Array.isArray(value)) return [];
  const turns: ChatTurn[] = [];
  for (const item of value.slice(-8)) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    if (row.role !== "user" && row.role !== "assistant") continue;
    if (typeof row.content !== "string") continue;
    const content = row.content.trim().slice(0, 2000);
    if (!content) continue;
    turns.push({ role: row.role, content });
  }
  return turns;
}

async function complete(userText: string, history: ChatTurn[], language: VoiceLanguage, style: NarrationStyle, key: string) {
  const res = await xaiFetch(CHAT_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "grok-4.5",
      max_tokens: 220,
      messages: [
        {
          role: "system",
          content: `You are NOVA, the voice of NOVA AI Studio. Reply only in ${LANG_NAME[language]}. ${STYLE_NOTE[style]} Two to four spoken sentences. No markdown, no lists, no stage directions.`,
        },
        ...history,
        { role: "user", content: userText },
      ],
    }),
  });
  if (!res.ok) return { ok: false as const, error: readError(res.status, await res.text()) };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const reply = body.choices?.[0]?.message?.content?.trim() ?? "";
  if (!reply) return { ok: false as const, error: "The assistant returned an empty reply." };
  return { ok: true as const, text: reply.slice(0, 1500) };
}

export const synthesizeSpeech = createServerFn({ method: "POST" })
  .validator((input: unknown) => assertSpeech(input))
  .handler(async ({ data }): Promise<SpeechResult> => {
    const key = apiKey();
    if (!key) return { ok: false, error: missingKey() };
    return synthesize(data, key);
  });

export const createVoiceSession = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") return {};
    return input as Record<string, unknown>;
  })
  .handler(async (): Promise<SessionResult> => {
    const key = apiKey();
    if (!key) return { ok: false, error: missingKey() };
    const res = await xaiFetch(SECRET_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ expires_after: { seconds: 300 } }),
    });
    if (!res.ok) return { ok: false, error: readError(res.status, await res.text()) };
    const body = (await res.json()) as { value?: string; expires_at?: number; client_secret?: { value?: string } };
    const token = body.value || body.client_secret?.value;
    if (!token) return { ok: false, error: "The voice service did not return a live session token." };
    return { ok: true, token, expiresAt: body.expires_at ?? 0 };
  });

export const speakTurn = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Missing conversation turn.");
    const data = input as Record<string, unknown>;
    const speech = assertSpeech({
      text: typeof data.text === "string" && data.text.trim() ? data.text : "turn",
      voiceId: data.voiceId,
      language: data.language,
      speed: data.speed,
      style: data.style,
    });
    const text = typeof data.text === "string" ? data.text.trim() : "";
    const audioBase64 = typeof data.audioBase64 === "string" ? data.audioBase64 : "";
    const mime = typeof data.mime === "string" ? data.mime.split(";")[0].trim().toLowerCase() : "";
    if (!text && !audioBase64) throw new Error("Record or type something first.");
    if (audioBase64 && !AUDIO_MIMES.has(mime)) throw new Error("That recording format is not supported.");
    if (!LANGUAGES.has(speech.language)) throw new Error("Choose English, Hindi, or Nepali.");
    return {
      speech,
      text,
      audioBase64,
      mime,
      history: cleanHistory(data.history),
    };
  })
  .handler(async ({ data }): Promise<TurnResult> => {
    const key = apiKey();
    if (!key) return { ok: false, error: missingKey() };

    let userText = data.text;
    if (data.audioBase64) {
      const heard = await transcribe(data.audioBase64, data.mime, data.speech.language, key);
      if (!heard.ok) return { ok: false, error: heard.error };
      userText = heard.text;
    }

    const reply = await complete(userText, data.history, data.speech.language, data.speech.style, key);
    if (!reply.ok) return { ok: false, error: reply.error, userText };

    const spoken = await synthesize(
      { ...data.speech, text: reply.text, style: "conversational" },
      key,
    );
    if (!spoken.ok) return { ok: false, error: spoken.error, userText, replyText: reply.text };
    return {
      ok: true,
      userText,
      replyText: reply.text,
      audioBase64: spoken.audioBase64,
      mime: "audio/mpeg",
      languageUsed: spoken.languageUsed,
    };
  });
