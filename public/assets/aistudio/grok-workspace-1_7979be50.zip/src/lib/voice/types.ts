export const LANGUAGES = [
  { id: "en", label: "English", code: "en" },
  { id: "hi", label: "Hindi", code: "hi" },
  { id: "ne", label: "Nepali", code: "ne" },
] as const;

export type VoiceLanguage = (typeof LANGUAGES)[number]["id"];

export const STYLES = [
  { id: "documentary", label: "Documentary", note: "Measured cinematic pace" },
  { id: "storytelling", label: "Storytelling", note: "Pauses between beats" },
  { id: "educational", label: "Educational", note: "Clear, normalized speech" },
  { id: "conversational", label: "Conversational", note: "Natural back-and-forth" },
] as const;

export type NarrationStyle = (typeof STYLES)[number]["id"];

export type VoiceGender = "female" | "male" | "neutral";

export type VoiceOption = {
  id: string;
  name: string;
  gender: VoiceGender;
  tone: string;
};

export type ChatTurn = {
  role: "user" | "assistant";
  content: string;
};

export type SpeechOk = {
  ok: true;
  audioBase64: string;
  mime: "audio/mpeg";
  languageUsed: string;
};

export type SpeechErr = { ok: false; error: string };

export type SpeechResult = SpeechOk | SpeechErr;

export type TurnResult = {
  ok: boolean;
  error?: string;
  userText?: string;
  replyText?: string;
  audioBase64?: string;
  mime?: "audio/mpeg";
  languageUsed?: string;
};

export type SessionResult =
  | { ok: true; token: string; expiresAt: number }
  | { ok: false; error: string };
