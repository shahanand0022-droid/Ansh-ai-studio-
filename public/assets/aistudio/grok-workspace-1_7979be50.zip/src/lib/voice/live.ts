import { bytesToBase64, downsample, floatToPcm16 } from "@/lib/voice/audio";
import type { NarrationStyle, VoiceLanguage } from "@/lib/voice/types";

const LANG_NAME: Record<VoiceLanguage, string> = {
  en: "English",
  hi: "Hindi",
  ne: "Nepali",
};

const STYLE_NOTE: Record<NarrationStyle, string> = {
  documentary: "You narrate like a cinematic documentary.",
  storytelling: "You tell stories with a close, human pace.",
  educational: "You explain clearly, like a good teacher.",
  conversational: "You talk like a natural conversation partner.",
};

type Handlers = {
  onUser: (id: string, text: string) => void;
  onAssistant: (id: string, text: string, done: boolean) => void;
  onError: (message: string) => void;
  onPhase: (phase: "listening" | "speaking") => void;
};

type StartOpts = {
  token: string;
  voiceId: string;
  language: VoiceLanguage;
  speed: number;
  style: NarrationStyle;
  volume: number;
};

export class LiveVoiceSession {
  private ws: WebSocket | null = null;
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private micAnalyser: AnalyserNode | null = null;
  private outAnalyser: AnalyserNode | null = null;
  private gain: GainNode | null = null;
  private nextTime = 0;
  private playbackUntil = 0;
  private sources: AudioBufferSourceNode[] = [];
  private pcmCarry = new Int16Array(0);
  private ready = false;
  private closed = false;
  private assistantId = "";
  private assistantText = "";

  constructor(private handlers: Handlers) {}

  get active() {
    return !this.closed && this.ws?.readyState === WebSocket.OPEN;
  }

  sample(into: Uint8Array<ArrayBuffer>): boolean {
    const mic = this.micAnalyser;
    const out = this.outAnalyser;
    if (!mic && !out) return false;
    const size = into.length;
    const micBins = new Uint8Array(new ArrayBuffer(size));
    const outBins = new Uint8Array(new ArrayBuffer(size));
    mic?.getByteTimeDomainData(micBins);
    out?.getByteTimeDomainData(outBins);
    let energyA = 0;
    let energyB = 0;
    for (let i = 0; i < size; i++) {
      energyA += Math.abs(micBins[i] - 128);
      energyB += Math.abs(outBins[i] - 128);
    }
    into.set(energyB > energyA ? outBins : micBins);
    return true;
  }

  setVolume(volume: number) {
    if (this.gain) this.gain.gain.value = volume;
  }

  async start(opts: StartOpts) {
    this.stop();
    this.closed = false;
    this.ready = false;
    this.ctx = new AudioContext();
    await this.ctx.resume();
    this.outAnalyser = this.ctx.createAnalyser();
    this.outAnalyser.fftSize = 2048;
    this.gain = this.ctx.createGain();
    this.gain.gain.value = opts.volume;
    this.outAnalyser.connect(this.gain).connect(this.ctx.destination);

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });

    const url = "wss://api.x.ai/v1/realtime?model=grok-voice-latest";
    const ws = new WebSocket(url, [`xai-client-secret.${opts.token}`]);
    this.ws = ws;
    ws.binaryType = "arraybuffer";

    await new Promise<void>((resolve, reject) => {
      const fail = () => reject(new Error("The live voice line could not connect."));
      ws.addEventListener("open", () => resolve(), { once: true });
      ws.addEventListener("error", fail, { once: true });
      window.setTimeout(fail, 12000);
    });

    ws.onmessage = (event) => {
      if (typeof event.data !== "string") return;
      this.onMessage(event.data);
    };
    ws.onerror = () => {
      if (!this.closed) this.handlers.onError("The live voice connection dropped.");
    };
    ws.onclose = () => {
      this.ready = false;
    };

    const hint = opts.language === "ne" ? "ne" : opts.language;
    ws.send(
      JSON.stringify({
        type: "session.update",
        session: {
          voice: opts.voiceId,
          instructions: `You are NOVA inside NOVA AI Studio. Reply only in ${LANG_NAME[opts.language]}. ${STYLE_NOTE[opts.style]} Keep each reply to two or four spoken sentences. No markdown.`,
          turn_detection: { type: "server_vad" },
          reasoning: { effort: "none" },
          audio: {
            input: {
              format: { type: "audio/pcm", rate: 24000 },
              transcription: { model: "grok-transcribe", language_hint: hint },
            },
            output: {
              format: { type: "audio/pcm", rate: 24000 },
              speed: Math.min(1.5, Math.max(0.7, opts.speed)),
            },
          },
        },
      }),
    );

    const source = this.ctx.createMediaStreamSource(this.stream);
    this.micAnalyser = this.ctx.createAnalyser();
    this.micAnalyser.fftSize = 2048;
    this.processor = this.ctx.createScriptProcessor(4096, 1, 1);
    source.connect(this.processor);
    this.processor.connect(this.micAnalyser);
    this.processor.onaudioprocess = (event) => this.onMic(event);
    window.setTimeout(() => {
      if (!this.closed) this.ready = true;
    }, 800);
    this.handlers.onPhase("listening");
  }

  sendText(text: string) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(
      JSON.stringify({
        type: "conversation.item.create",
        item: {
          type: "message",
          role: "user",
          content: [{ type: "input_text", text }],
        },
      }),
    );
    this.ws.send(JSON.stringify({ type: "response.create" }));
    this.handlers.onUser(`typed-${Date.now()}`, text);
  }

  interrupt() {
    this.stopPlayback();
    this.playbackUntil = 0;
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: "response.cancel" }));
      this.ws.send(JSON.stringify({ type: "input_audio_buffer.clear" }));
    }
    this.handlers.onPhase("listening");
  }

  stop() {
    this.closed = true;
    this.ready = false;
    this.processor?.disconnect();
    this.processor = null;
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    this.stopPlayback();
    if (this.ws && this.ws.readyState < WebSocket.CLOSING) this.ws.close();
    this.ws = null;
    void this.ctx?.close();
    this.ctx = null;
    this.micAnalyser = null;
    this.outAnalyser = null;
    this.gain = null;
    this.pcmCarry = new Int16Array(0);
  }

  private stopPlayback() {
    for (const source of this.sources) {
      try {
        source.stop();
      } catch {
        /* already stopped */
      }
    }
    this.sources = [];
    this.nextTime = 0;
  }

  private onMic(event: AudioProcessingEvent) {
    if (!this.ready || !this.ctx || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    if (this.ctx.currentTime < this.playbackUntil) return;
    const channel = event.inputBuffer.getChannelData(0);
    const pcm = floatToPcm16(downsample(channel, this.ctx.sampleRate, 24000));
    const merged = new Int16Array(this.pcmCarry.length + pcm.length);
    merged.set(this.pcmCarry, 0);
    merged.set(pcm, this.pcmCarry.length);
    const frame = 2400;
    let offset = 0;
    while (merged.length - offset >= frame) {
      const slice = merged.subarray(offset, offset + frame);
      const bytes = new Uint8Array(slice.buffer, slice.byteOffset, slice.byteLength);
      const copy = new Uint8Array(bytes.byteLength);
      copy.set(bytes);
      this.ws.send(JSON.stringify({ type: "input_audio_buffer.append", audio: bytesToBase64(copy) }));
      offset += frame;
    }
    this.pcmCarry = merged.subarray(offset).slice();
  }

  private playPcm(b64: string) {
    if (!this.ctx || !this.outAnalyser) return;
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const samples = new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
    const audio = this.ctx.createBuffer(1, samples.length, 24000);
    const channel = audio.getChannelData(0);
    for (let i = 0; i < samples.length; i++) channel[i] = samples[i] / 32768;
    const source = this.ctx.createBufferSource();
    source.buffer = audio;
    source.connect(this.outAnalyser);
    const now = this.ctx.currentTime;
    if (this.nextTime < now + 0.02) this.nextTime = now + 0.04;
    source.start(this.nextTime);
    this.nextTime += audio.duration;
    this.playbackUntil = this.nextTime;
    this.sources.push(source);
    this.handlers.onPhase("speaking");
  }

  private onMessage(raw: string) {
    let event: Record<string, unknown>;
    try {
      event = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return;
    }
    const type = String(event.type ?? "");
    if (type === "session.updated" || type === "session.created") {
      if (type === "session.updated") this.ready = true;
      return;
    }
    if (type === "error") {
      const err = event.error as { message?: string } | string | undefined;
      const message = typeof err === "string" ? err : err?.message;
      this.handlers.onError(message || "The live voice session reported an error.");
      return;
    }
    if (type === "input_audio_buffer.speech_started") {
      this.stopPlayback();
      this.playbackUntil = 0;
      this.handlers.onPhase("listening");
      return;
    }
    if (type === "conversation.item.input_audio_transcription.updated") {
      const text = String(event.transcript ?? event.text ?? "").trim();
      const id = String(event.item_id ?? "user");
      if (text) this.handlers.onUser(id, text);
      return;
    }
    if (
      type === "response.output_audio_transcript.delta" ||
      type === "response.audio_transcript.delta" ||
      type === "response.output_text.delta" ||
      type === "response.text.delta"
    ) {
      if (!this.assistantId) this.assistantId = String(event.response_id ?? `nova-${Date.now()}`);
      this.assistantText += String(event.delta ?? "");
      this.handlers.onAssistant(this.assistantId, this.assistantText, false);
      return;
    }
    if (type.endsWith("transcript.done") || type === "response.output_audio_transcript.done") {
      const text = String(event.transcript ?? this.assistantText).trim();
      if (!this.assistantId) this.assistantId = String(event.response_id ?? `nova-${Date.now()}`);
      if (text) {
        this.assistantText = text;
        this.handlers.onAssistant(this.assistantId, text, true);
      }
      return;
    }
    if (type === "response.output_audio.delta" || type === "response.audio.delta") {
      const delta = event.delta;
      if (typeof delta === "string" && delta) this.playPcm(delta);
      return;
    }
    if (type === "response.done" || type === "response.output_audio.done") {
      if (this.assistantId && this.assistantText.trim()) {
        this.handlers.onAssistant(this.assistantId, this.assistantText.trim(), true);
      }
      this.assistantId = "";
      this.assistantText = "";
      window.setTimeout(() => {
        if (this.ctx && this.ctx.currentTime >= this.playbackUntil - 0.05) {
          this.handlers.onPhase("listening");
        }
      }, 300);
    }
  }
}
