const MAX_SCENES = 8;
const MAX_CHARS = 1600;

function splitLong(text: string): string[] {
  const parts: string[] = [];
  let rest = text.trim();
  while (rest.length > MAX_CHARS) {
    let cut = rest.lastIndexOf(" ", MAX_CHARS);
    if (cut < 400) cut = MAX_CHARS;
    parts.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  if (rest) parts.push(rest);
  return parts;
}

export function splitScript(input: string): { scenes: string[]; truncated: boolean } {
  const text = input.replace(/\r\n/g, "\n").trim();
  if (!text) return { scenes: [], truncated: false };

  const marked = text.split(/\n+(?=(?:scene\b|#{1,3}\s|INT\.|EXT\.))/i);
  let chunks = marked.length > 1 ? marked : text.split(/\n\s*\n/);
  chunks = chunks.map((chunk) => chunk.trim()).filter(Boolean);
  if (chunks.length === 1 && chunks[0].length > MAX_CHARS) {
    const sentences = chunks[0].split(/(?<=[.!?।])\s+/);
    chunks = sentences.length > 1 ? sentences : chunks;
  }

  const sized = chunks.flatMap((chunk) => (chunk.length > MAX_CHARS ? splitLong(chunk) : [chunk]));
  if (sized.length <= MAX_SCENES) return { scenes: sized, truncated: false };

  const head = sized.slice(0, MAX_SCENES - 1);
  const tail = sized.slice(MAX_SCENES - 1).join("\n\n");
  const clipped = tail.length > MAX_CHARS ? tail.slice(0, MAX_CHARS).trim() : tail;
  return { scenes: [...head, clipped], truncated: true };
}

export function sceneTitle(text: string, index: number): string {
  const line = text
    .split("\n")
    .map((row) => row.trim())
    .find(Boolean);
  const clean = (line ?? `Scene ${index + 1}`).replace(/^#+\s*/, "").slice(0, 72);
  return clean || `Scene ${index + 1}`;
}
